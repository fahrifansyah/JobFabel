<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('JobApplication', function (Blueprint $table) {
            $table->id();      
            $table->integer('job_id');      
            $table->integer('company_id');        
            $table->integer('jobseeker_id');                         
            $table->string('name');   
            $table->string('dob');      
            $table->string('experience');   
            $table->string('phone');   
            $table->text('description');   
            $table->char('gender');   
            $table->text('address');   
            $table->string('disability');   
            $table->string('status');   
            $table->string('bookmark');   
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('CompanyCategory');
    }
};
