<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('Job', function (Blueprint $table) {
            $table->id();      
            $table->integer('company_id');      
            $table->integer('category_id'); 
            $table->text('category'); 
            $table->string('name');   
            $table->text('description');   
            $table->text('requirement');   
            $table->text('salary');      
            $table->integer('city_id');  
            $table->text('city');  
            $table->string('operation');    
            $table->string('info');
            $table->string('disability'); 
            $table->boolean('is_active')->default(true);
            $table->string('slugs');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('Job');
    }
};
