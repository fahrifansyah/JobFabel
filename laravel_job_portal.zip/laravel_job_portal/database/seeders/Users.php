<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Str;

class Users extends Seeder
{
    
    public function run(): void
    {
        User::create([
            'username' => 'fahri',
            'email' => 'fahri@gmail.com',
            'email_verified_at' => now(),
            'password' => 'fahri', // password
            'is_user' => 2,
            'remember_token' => Str::random(10),
        ]);
        User::create([
            'username' => 'garry',
            'email' => 'garry@gmail.com',
            'email_verified_at' => now(),
            'password' => 'garry', // password
            'is_user' => 1,
            'remember_token' => Str::random(10),
        ]);
    }
}
