<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="<?php echo e(asset('assets/jobfable/user/style-editprofil.css')); ?>" />
    <title>Edit Profil</title>
</head>

<body>
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- NAVBAR -->
    <div class="container">
        <!-- NAVBAR -->
        <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        <?php if($is_user==1): ?>
            <a id="ja_list" href="<?php echo e(route('jobapplication.list')); ?>">Riwayat Lamaran</a>
            <a id="j_detail" href="<?php echo e(route('jobapplication.detail')); ?>">Daftar Pekerjaan</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <a id="js_bookmark" href="<?php echo e(route('jobapplication.bookmarklist')); ?>">Tinjau Ulang</a>
        <?php elseif($is_user==2): ?>
            <a id="j_list" href="<?php echo e(route('job.list')); ?>">Buka Lowongan Kerja</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <?php endif; ?>
            <?php if(! $is_user): ?>               
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            <?php endif; ?>
        </div>
        <div class="navbar-extra">
             <?php if($is_user==1): ?>
             <a href="<?php echo e(route('jobapplication.detail')); ?>" id="search"><i data-feather="search"></i></a>
            <a href="<?php echo e(route('jobseeker.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>
            <?php elseif($is_user==2): ?>
            <a href="<?php echo e(route('search.index')); ?>" id="search"><i data-feather="search"></i></a>  
            <a href="<?php echo e(route('company.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>            
            <?php endif; ?>
        </div>
    </nav>
        <!-- NAVBAR END -->
        <!-- PROFIL START -->
        <section id="edit-profil" class="edit-profil">
            <form method="post" action="<?php echo e(route('jobseeker.update')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="jobseeker_id" value="<?php echo e($jobseeker->id); ?>">
                <h2><span>Edit Profil</span></h2>
                <div class="edit-div">
                    <div class="name">
                        <label for="name">Nama Lengkap</label><br>
                        <input type="text" required id="name" name="jobseeker_username" value="<?php echo e($user->username); ?>"
                            minlength="5">
                        <span class="validity"></span>
                    </div>
                    <!-- <div class="info">
        <label for="info">Informasi Diri</label><br>
        <input type="text" id="info" name="info" placeholder="(optional)">
      </div> -->
                    <div class="desc">
                        <label for="desc">Deskripsi</label><br>
                        <textarea id="desc" name="jobseeker_description" placeholder="Deskripsi (optional)" required><?php echo e(htmlspecialchars_decode($jobseeker->description)); ?></textarea>


                        <span class="validity"></span>
                    </div>
                    <div class="dob">
                        <label for="dob">Tanggal Lahir</label><br>
                        <input type="date" id="dob" name="jobseeker_dob" value="<?php echo e($jobseeker->dob); ?>"
                            min="1950-01-01" max="today">
                        <span class="validity"></span>
                    </div>
                    <div class="gender">
                        <label for="gender">Jenis Kelamin</label><br>
                        <select name="gender" name="jobseeker_gender" value="<?php echo e($jobseeker->gender); ?>"
                            id="gender">
                            <option value="select">Pilih</option>
                            <option value="male">Laki-laki</option>
                            <option value="female">Perempuan</option>
                        </select>
                    </div>
                    <div class="username">
                        <label for="username">Username(5-8 karakter)</label><br>
                        <input type="text" required id="username" name="jobseeker_username"
                            value="<?php echo e($user->username); ?>" minlength="5" maxlength="8" size="10">
                        <span class="validity"></span>
                    </div>
                    <div class="email">
                        <label for="email">Email</label><br>
                        <input type="email" id="email" name="jobseeker_email" value="<?php echo e($user->email); ?>"
                            placeholder="example@gmail.com">
                        <span class="validity"></span>
                    </div>
                    <div class="phone">
                        <label for="phone">No. Telepon</label><br>
                        <input type="text" required id="phone" name="jobseeker_phone"
                            value="<?php echo e($jobseeker->phone); ?>">
                        <span class="validity"></span>
                    </div>
                    <div class="phone">
                        <label for="phone">Alamat</label><br>
                        <input type="text" required id="phone" name="jobseeker_address"
                            value="<?php echo e($jobseeker->address); ?>">
                        <span class="validity"></span>
                    </div>
                    <div class="password">
                        <label for="password">Password</label><br>
                        <input id="password" type="password" name="jobseeker_password" placeholder="Password"
                            minlength="5" maxlength="8">
                        <span class="validity"></span>
                    </div>
                    <div class="disability">
                        <label for="disability">Jenis Disabilitas</label>
                        <div >
                            <label>
                                <input type="checkbox" name="disability[]" value="Tuna netra" <?php if(in_array('Tuna netra', $selectedDisabilities)): ?> checked <?php endif; ?>>
                                Tuna netra
                            </label><br>
                            <label>
                                <input type="checkbox" name="disability[]" value="Tuna rungu" <?php if(in_array('Tuna rungu', $selectedDisabilities)): ?> checked <?php endif; ?>>
                                Tuna rungu
                            </label><br>
                            <label>
                                <input type="checkbox" name="disability[]" value="Tuna wicara" <?php if(in_array('Tuna wicara', $selectedDisabilities)): ?> checked <?php endif; ?>>
                                Tuna wicara
                            </label><br>
                            <label>
                                <input type="checkbox" name="disability[]" value="Tuna haptic/Tuna kinestetik" <?php if(in_array('Tuna haptic/Tuna kinestetik', $selectedDisabilities)): ?> checked <?php endif; ?>>
                                Tuna haptic/Tuna kinestetik
                            </label><br>
                        </div>
                    </div>
                    <!-- <div class="skill">
        <label for="skill">Kemampuan</label><br>
        <input type="text" id="skill"  minlength="5" required>
        <span class="validity"></span>
      </div> -->
                    <div class="upload-cv">
                        <label for="upload-cv">Upload CV</label>
                        <input type="file" id="upload-cv" name="job_seeker_file" accept=".doc, .docx, .pdf">
                        <span class="validity"></span>
                    </div>
                    <div class="education">
                        <label for="education">Pendidikan</label><br>
                        <!-- <input type="text" id="education" name="education" placeholder="Nama Sekolah" required>
        <span class="validity"></span>
        <input type="text" id="education" name="education" placeholder="Tingkat" required>
        <span class="validity"></span>
        <input type="text" id="education" name="education" placeholder="Bidang Studi" required>
        <span class="validity"></span><br> -->
        <textarea id="edu-desc" name="jobseeker_education" placeholder="Pendidikan (optional)"><?php echo e($jobseeker->education); ?></textarea>

                        <!-- <label for="start">Tanggal Mulai</label>
        <input type="date" id="start" name="start" min="1950-01-01" max="2099-12-31" required>
        <span class="validity"></span>

       <label for="end">Tanggal Selesai</label>
       <input type="date" id="end" name="end" min="1950-01-01" max="2099-12-31" required>
       <span class="validity"></span> -->
                    </div>
                    <div class="experience">
                        <label for="experience">Pengalaman</label><br>
                        <!-- <input type="text" id="experience"  placeholder="Nama Perusahaan" required>
        <span class="validity"></span>
        <input type="text" id="experience" name="experience" placeholder="Posisi/Jabatan" required>
        <span class="validity"></span><br> -->
        <textarea id="exp-desc" name="jobseeker_experience" placeholder="Pengalaman (optional)" required><?php echo e($jobseeker->experience); ?></textarea>

                        <!-- <label for="start">Tanggal Mulai</label>
        <input type="date" id="start" name="start" min="1950-01-01" max="2099-12-31" required>
        <span class="validity"></span>

       <label for="end">Tanggal Selesai</label>
       <input type="date" id="end" name="end" min="1950-01-01" max="2099-12-31" required>
       <span class="validity"></span> -->
                    </div>
                    <div class="profil-pic">
                        <label for="profil-pic">Upload Foto Profil</label>
                        <input type="file" id="profil-pic" name="job_seeker_image"
                            accept="image/png, image/jpeg">
                        <span class="validity"></span>
                    </div>
                </div>
                <div class="submit-button">
                    <div class="row">
                        <button class="save" type="submit">Simpan</button>
                        <a href="<?php echo e(route('jobseeker.index')); ?>"  class="cancel">
                            Batal
                        </a>
                    </div>
                </div>
            </form>
        </section>
        <!-- PROFIL END -->
        <!-- BUTTON START -->
        <!-- BUTTON END -->

        <!-- FOOTER START-->
        <footer>
            <div class="social">
              <a href="#"><i data-feather="mail"></i> </a>
            </div>
            <div class="links">
              <a href="<?php echo e(url('/')); ?>#home">Home</a>
              <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
            </div>
            <div class="credit">
              <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
            </div>
          </footer>
    </div>
    <!-- my javascript -->
    <script src="script.js"></script>
    <!-- Feather Icons-->
    <script>
        feather.replace();
    </script>
    <script>
        <?php if($message = session('success')): ?>
            Swal.fire(
                'Berhasil!',
                '<?php echo e($message); ?>',
                'success'
            )
        <?php endif; ?>
        <?php if($message = session('error')): ?>
            Swal.fire(
                'Gagal!',
                '<?php echo e($message); ?>',
                'error'
            )
        <?php endif; ?>
    </script>


<script>
    $(document).ready(function() {
        $('form').submit(function(event) {
            event.preventDefault();

            var form = $(this);
            var url = form.attr('action');
            var formData = new FormData(form[0]);

            $.ajax({
                url: url,
                type: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    Swal.fire(
                            'Berhasil!',
                            'Data Berhasil di Update',
                            'success'
                        )
                        .then(function() {
                            // Redirect ke halaman lain jika perlu
                            window.location.href = "<?php echo e(route('jobseeker.index')); ?>";
                        });
                },
                error: function(xhr, status, error) {
                    var errorMessage = xhr.responseJSON.message;
                     Swal.fire('Error', errorMessage, 'error');
                }
            });
        });
    });
</script>
</body>

</html>
<?php /**PATH D:\Downloads\laravel_job_portal (4)\laravel_job_portal\resources\views/user/edit_profil.blade.php ENDPATH**/ ?>