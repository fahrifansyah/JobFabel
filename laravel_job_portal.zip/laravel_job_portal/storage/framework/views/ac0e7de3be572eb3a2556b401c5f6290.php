<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">    
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
    <link rel="stylesheet" href="<?php echo e(asset('assets/jobfable/user/style-jobdetail.css')); ?>" />
    <title>Job Detail</title>
  </head>
  <body>
        <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
      <script src="https://unpkg.com/feather-icons"></script>

    <div class="container">
      <!-- NAVBAR -->
      <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        <?php if($is_user==1): ?>
            <a id="ja_list" href="<?php echo e(route('jobapplication.list')); ?>">Riwayat Lamaran</a>
            <a id="j_detail" href="<?php echo e(route('jobapplication.detail')); ?>">Daftar Pekerjaan</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <a id="js_bookmark" href="<?php echo e(route('jobapplication.bookmarklist')); ?>">Tinjau Ulang</a>
        <?php elseif($is_user==2): ?>
            <a id="j_list" href="<?php echo e(route('job.list')); ?>">Buka Lowongan Kerja</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <?php endif; ?>
            <?php if(! $is_user): ?>              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            <?php endif; ?>
        </div>
        <div class="navbar-extra">
             <?php if($is_user==1): ?>
             <a href="<?php echo e(route('jobapplication.detail')); ?>" id="search"><i data-feather="search"></i></a>
            <a href="<?php echo e(route('jobseeker.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>
            <?php elseif($is_user==2): ?>
            <a href="<?php echo e(route('search.index')); ?>" id="search"><i data-feather="search"></i></a>  
            <a href="<?php echo e(route('company.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>            
            <?php endif; ?>
        </div>
    </nav>
      <!-- NAVBAR END -->

      <!-- HEAD START -->
     
        <?php if($listJob): ?>
        <?php $__currentLoopData = $listJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <section id="job-detail" class="job-detail"> 
        <h2><span>Detail Pekerjaan</span></h2>

        <div class="row">
          <div class="Profil-img">
            <img src="<?php echo e(asset('uploads')); ?>/<?php echo e($job->image); ?>" />
          </div>
          <div class="desc">
            <h3><?php echo e($job->name); ?></h3>
            <h4><?php echo e($job->c_name); ?></h4>
            <p><?php echo e($job->address); ?></p>
            <p><?php echo e($job->salary); ?></p>
          </div>
          <div class="apply-button">
           
          </div>
        </div>
      </section>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
      <!-- PROFIL END -->
       <?php if($listJob): ?>
            <?php $__currentLoopData = $listJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list => $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <!-- ABOUT THE JOB START -->
      <section id="description" class="description">
        <h2>Tentang Pekerjaan</h2>

        <div class="desc">
          <br />
          

          <h4>Deskripsi Pekerjaan</h4>
          <div class="li-desc">
            <p style="white-space: pre-line"><?php echo e($job->description); ?></p>
          </div>

          <h4>Minimum Kualifikasi</h4>
          <div class="li-desc">
            <p style="white-space: pre-line"><?php echo e($job->requirement); ?></p>
          </div>

          <h4>Jenis Pekerjaan</h4>
          <p><?php echo e($job->category); ?></p>

          <h4>Jam Kerja/Operasional</h4>
          <p><?php echo e($job->operation); ?></p>
          
          <section id="experience" class="experience">
            <h4>Jenis Disabilitas</h4>
            <div class="job">
                <?php if($job->disability): ?>
                <ul>
                  <?php
                    $disabilities = explode(',', $job->disability);
                  ?>
                  <?php $__currentLoopData = $disabilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $disability): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e(trim($disability)); ?></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              <?php endif; ?>
            </div>
        </section>
        <br>
        <br>
          
          <h4>Informasi Tambahan</h4>
          <p style="white-space: pre-line"><?php echo e($job->info); ?></p>
        </div>
      </section>
      <!-- ABOUT THE JOB END -->

      <!-- ABOUT THE COMPANY -->
      <section id="description" class="description">
        <h2>Tentang Perusahaan</h2>

        <div class="desc">
          <br />
          

          <h4>Jenis Perusahaan</h4>
          <p><?php echo e($job->c_category); ?></p>

          
          <h4>Alamat</h4>
          <p><?php echo e($job->address); ?></p>

          

          <h4>Website</h4>
          <p>
            <a href="<?php echo e($job->website); ?>"><?php echo e($job->website); ?></a>
          </p>
        </div>
      </section>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
      <!-- ABOUT THE COMPANY END -->
      <br />
      <!-- BACK BUTTON -->
      <div class="back-button">
        <a href="<?php echo e(route('job.list')); ?>">
          <button class="back" type="submit">Kembali</button>
        </a>
      </div>

      <!-- FOOTER START-->
      <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    </div>
    <!-- FOOTER END -->

    <!-- my javascript -->
    <script src="script.js"></script>

    <!-- Feather Icons-->
    <script>
      feather.replace();
    </script>
  </body>
</html>
<?php /**PATH D:\Downloads\laravel_job_portal (4)\laravel_job_portal\resources\views/company/job_detail.blade.php ENDPATH**/ ?>