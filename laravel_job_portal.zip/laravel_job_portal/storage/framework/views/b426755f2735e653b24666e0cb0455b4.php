<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('konten-jobseeker-1.css')); ?>" />
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>About Job</title>
</head>

<body>
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
    </nav>
    </header>
    <!-- navbar end -->
    <main>
        <h1>Membangun Jaringan Profesional yang Kuat sebagai Pekerja Disabilitas</h1>
        <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Disabilitas3.jpg" alt="jobseeker-3">
        <p>Memiliki jaringan profesional yang kuat sangat penting bagi semua pekerja, termasuk mereka yang memiliki
            disabilitas. Jaringan yang baik dapat membuka pintu kesempatan kerja, memberikan dukungan, dan memperluas
            lingkaran kontak di dunia bisnis. Berikut adalah beberapa tips dan trik untuk membantu pekerja disabilitas
            membangun jaringan profesional yang kuat: <br><br>

            1. Bergabung dengan Komunitas dan Organisasi Terkait: Cari tahu tentang komunitas dan organisasi yang
            terkait dengan disabilitas di bidang pekerjaan Anda. Bergabunglah dengan grup diskusi online, forum, atau
            acara komunitas terkait untuk bertemu dengan orang-orang yang memiliki pengalaman serupa dan membangun
            hubungan yang saling mendukung. <br><br>

            2. Menghadiri Acara dan Seminar: Seringkali ada acara dan seminar yang ditujukan untuk pekerja dengan
            disabilitas atau topik terkait inklusi di tempat kerja. Manfaatkan kesempatan ini untuk memperluas jaringan
            Anda. Jangan ragu untuk berinteraksi dengan peserta lain, berbagi pengalaman, dan bertukar informasi kontak.
            <br><br>

            3. Memanfaatkan Media Sosial: Gunakan media sosial, seperti LinkedIn atau Twitter, untuk membangun dan
            memperluas jaringan profesional Anda. Buat profil yang informatif dan profesional, ikuti dan terlibat dengan
            orang-orang di industri Anda, dan aktif dalam berbagi informasi dan pendapat yang relevan. <br><br>

            4. Menghadiri Konferensi dan Pameran Karir: Konferensi dan pameran karir adalah tempat yang bagus untuk
            bertemu dengan profesional dari berbagai industri. Pastikan untuk mencari acara yang mendorong inklusi dan
            kesetaraan kesempatan kerja. Jangan ragu untuk berbicara dengan orang-orang, bertanya tentang pekerjaan
            mereka, dan menukar kartu nama. <br><br>

            5. Mentoring dan Konseling: Cari mentor atau konselor yang bisa membimbing dan memberikan nasihat tentang
            perkembangan karir Anda. Mereka dapat membantu Anda menjelajahi peluang, mengembangkan keterampilan, dan
            memperluas jaringan kontak Anda. <br><br>

            6. Membangun Kemitraan dengan Rekan Kerja: Jalin hubungan yang kuat dengan rekan kerja Anda. Bekerja sama
            dalam proyek, berbagi pengetahuan dan pengalaman, dan saling mendukung dapat membantu membangun jaringan
            yang solid di tempat kerja.<br><br>

            7. Mengikuti Pelatihan dan Program Pengembangan Profesional: Manfaatkan pelatihan dan program pengembangan
            profesional yang ditawarkan oleh perusahaan atau lembaga terkait. Selain memperluas keterampilan Anda, Anda
            juga akan bertemu dengan orang-orang baru dan dapat memperluas jaringan profesional Anda. <br><br>

            8. Jaga Hubungan yang Ada: Jaringan profesional tidak hanya tentang membangun hubungan baru, tetapi juga
            memelihara hubungan yang sudah ada. Tetaplah terhubung dengan orang-orang di jaringan Anda, lakukan
            pertemuan atau panggilan rutin, dan tawarkan dukungan jika diperlukan. <br><br>

            Membangun jaringan profesional yang kuat sebagai pekerja disabilitas mungkin membutuhkan sedikit usaha
            ekstra, tetapi manfaat jangka panjangnya akan sangat berharga. Dengan memanfaatkan kesempatan yang ada dan
            mengambil inisiatif dalam membangun hubungan, Anda dapat menciptakan jaringan yang kuat yang akan mendukung
            Anda dalam perjalanan karir Anda. Ingatlah untuk tetap terbuka, aktif, dan menghargai setiap hubungan yang
            Anda bangun.


        </p>
        <!-- BACK BUTTON -->
        <div class="back-button">
            <a href="<?php echo e(route('company.about')); ?>">
                <button class="back" type="submit">Kembali</button>
            </a>
        </div>
    </main>
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
  <!-- Footer End -->
  <script>
      feather.replace();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
  </script>
</body>

</html>

<?php /**PATH C:\xampp\htdocs\laravel_job_portal\resources\views/about/konten-jobseeker-3.blade.php ENDPATH**/ ?>