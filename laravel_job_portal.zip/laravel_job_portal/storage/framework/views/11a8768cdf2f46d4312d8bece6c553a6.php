<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/jobfable/company/seputarkerja.css')); ?>" />
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>About Job</title>
</head>

<body>
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        <?php if($is_user==1): ?>
            <a id="ja_list" href="<?php echo e(route('jobapplication.list')); ?>">Riwayat Lamaran</a>
            <a id="j_detail" href="<?php echo e(route('jobapplication.detail')); ?>">Daftar Pekerjaan</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <a id="js_bookmark" href="<?php echo e(route('jobapplication.bookmarklist')); ?>">Tinjau Ulang</a>
        <?php elseif($is_user==2): ?>
            <a id="j_list" href="<?php echo e(route('job.list')); ?>">Buka Lowongan Kerja</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <?php endif; ?>
            <?php if(! $is_user): ?>              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            <?php endif; ?>
        </div>
        <div class="navbar-extra">
             <?php if($is_user==1): ?>
             <a href="<?php echo e(route('jobapplication.detail')); ?>" id="search"><i data-feather="search"></i></a>
            <a href="<?php echo e(route('jobseeker.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>
            <?php elseif($is_user==2): ?>
            <a href="<?php echo e(route('search.index')); ?>" id="search"><i data-feather="search"></i></a>  
            <a href="<?php echo e(route('company.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>            
            <?php endif; ?>
        </div>
    </nav>
    </header>
    <!-- navbar end -->

    <!-- Seputar kerja Start -->
    <main>
        <h1>Seputar Kerja</h1>
        <section class="jobseeker">
            <h3>Pencari Kerja</h3>
            <div class="card-jobseeker">
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Disabilitas1.jpg" alt="service 1 images">
                    <h4>Mengatasi Tantangan dalam Karir bagi Disabilitas</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-jobseeker-1')); ?>"
                        role="button">Selengkapnya</a>
                </div>
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Disabilitas2.jpg" alt="service 2 images">
                    <h4>Pentingnya Aksesibilitas di Tempat Kerja untuk Pekerja Disabilitas</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-jobseeker-2')); ?>"
                        role="button">Selengkapnya</a>
                </div>
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Disabilitas3.jpg" alt="service 3 images">
                    <h4>Membangun Jaringan Profesional yang Kuat sebagai Pekerja Disabilitas</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-jobseeker-3')); ?>"
                        role="button">Selengkapnya</a>
                </div>
            </div>
        </section>
        <section class="company">
            <h3>Perusahaan</h3>
            <div class="card-company">
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Company1.jpg" alt="service 1 images">
                    <h4>Menyesuaikan Proses Rekrutmen untuk Menyambut Pekerja Disabilitas</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-company-1')); ?>"
                        role="button">Selengkapnya</a>
                </div>
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Company2.png" alt="service 2 images">
                    <h4>Membangun Kemitraan dengan Organisasi Pekerja Disabilitas</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-company-2')); ?>"
                        role="button">Selengkapnya</a>
                </div>
                <div class="card-jobseeker-item">
                    <img src="<?php echo e(asset('assets/jobfable/img')); ?>/Company3.jpg" alt="service 3 images">
                    <h4>Cara Membangun Budaya Kerja yang Kolaboratif dan Inklusif</h4>
                    <a class="card-btn btn btn-outline-primary p-2" href="<?php echo e(route('konten-company-3')); ?>"
                        role="button">Selengkapnya</a>
                </div>
            </div>
        </section>
    </main>
    <!-- Seputar kerja End -->

    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer End -->
    <script>
        feather.replace();
    </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel_job_portal\resources\views/company/seputarkerja.blade.php ENDPATH**/ ?>