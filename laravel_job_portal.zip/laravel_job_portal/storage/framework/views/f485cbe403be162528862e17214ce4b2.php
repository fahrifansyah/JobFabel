<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('konten-company-2.css')); ?>" />
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>About Job</title>
</head>

<body>
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
    </nav>
    </header>
    <!-- navbar end -->
    <main>
        <h1>Membangun Kemitraan dengan Organisasi Pekerja Disabilitas</h1>
        <img src="<?php echo e(asset('assets/jobfable/img/Company2.png')); ?>" alt="company-2">
        <p>Dalam upaya untuk menciptakan tempat kerja yang inklusif dan mendukung pekerja dengan disabilitas, membangun
            kemitraan dengan organisasi yang fokus pada dukungan dan advokasi bagi individu dengan disabilitas adalah
            langkah yang sangat penting. Berikut ini adalah beberapa tips dan trik penting yang dapat membantu
            perusahaan membangun kemitraan yang kuat dengan organisasi yang mendukung pekerja disabilitas: <br><br>

            1. Identifikasi Organisasi yang Relevan: Lakukan penelitian untuk mengidentifikasi organisasi yang secara
            khusus mendukung pekerja dengan disabilitas. Cari organisasi yang memiliki pengalaman, pengetahuan, dan
            jaringan yang luas dalam hal ini.<br><br>

            2. Hubungi Organisasi Tersebut: Hubungi organisasi yang telah Anda identifikasi dan jelaskan minat Anda
            dalam membangun kemitraan yang saling menguntungkan. Tunjukkan komitmen perusahaan Anda terhadap inklusi dan
            keberagaman.<br><br>

            3. Pertemuan dan Diskusi: Sengaja atur pertemuan dengan perwakilan organisasi tersebut. Gunakan kesempatan
            ini untuk berdiskusi secara lebih rinci mengenai tujuan dan visi masing-masing pihak. Dapatkan wawasan
            tentang kebutuhan dan tantangan yang dihadapi oleh pekerja dengan disabilitas serta cara terbaik untuk
            memberikan dukungan.<br><br>

            4. Menentukan Kemitraan yang Tepat: Diskusikan potensi kemitraan yang dapat dibangun, seperti program
            pelatihan atau penempatan pekerja, pertukaran pengetahuan, atau kampanye kesadaran bersama. Tentukan cara
            bagaimana kedua belah pihak dapat saling mendukung dan melengkapi dalam mencapai tujuan yang sama.<br><br>

            5. Kolaborasi dalam Program dan Acara: Bekerjasama dengan organisasi tersebut dalam mengembangkan program
            atau acara yang berkaitan dengan inklusi dan keberagaman. Misalnya, mengadakan seminar atau workshop
            bersama, menjadi sponsor dalam acara mereka, atau berpartisipasi dalam kegiatan sukarela.<br><br>

            6. Pertimbangkan Program Magang atau Penempatan Kerja: Diskusikan kemungkinan untuk menyediakan program
            magang atau penempatan kerja bagi individu dengan disabilitas melalui kemitraan ini. Ini akan memberikan
            peluang berharga bagi pekerja dengan disabilitas untuk mendapatkan pengalaman kerja dan membantu mereka
            memperluas jaringan profesional mereka.<br><br>

            7. Evaluasi dan Komunikasi Terus-Menerus: Tetaplah berkomunikasi secara teratur dengan organisasi mitra
            untuk mengevaluasi progres kemitraan dan melakukan perbaikan jika diperlukan. Dengan menjaga komunikasi yang
            terbuka, dapat dibangun kerja sama yang lebih baik dan solusi yang lebih efektif.<br><br>

            8. Bagikan Keberhasilan Bersama: Saat mencapai keberhasilan melalui kemitraan ini, berbagi kisah sukses dan
            pencapaian dengan organisasi mitra serta dengan publik. Ini akan memperkuat hubungan dan membangun kesadaran
            yang lebih luas tentang pentingnya inklusi bagi pekerja dengan disabilitas.<br><br>

            Membangun kemitraan yang kuat dengan organisasi yang mendukung pekerja disabilitas bukan hanya memberikan
            manfaat bagi individu dengan disabilitas tetapi juga dapat meningkatkan citra perusahaan dan memperkaya
            lingkungan kerja. Dengan mengikuti tips dan trik di atas, perusahaan dapat menjadi agen perubahan dalam
            menciptakan tempat kerja yang inklusif dan memberikan peluang yang setara bagi semua individu, termasuk
            mereka dengan disabilitas.
        </p>
        <!-- BACK BUTTON -->
        <div class="back-button">
            <a href="<?php echo e(route('company.about')); ?>">
                <button class="back" type="submit">Kembali</button>
            </a>
        </div>
    </main>
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
  <!-- Footer End -->
  <script>
      feather.replace();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
  </script>
</body>

</html>

<?php /**PATH C:\xampp\htdocs\laravel_job_portal\resources\views/about/konten-company-2.blade.php ENDPATH**/ ?>