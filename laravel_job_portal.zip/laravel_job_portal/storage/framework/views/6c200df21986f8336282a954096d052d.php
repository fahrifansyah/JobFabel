<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>search</title>

    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />

    <!-- Feather iconsa -->
    <script src="https://unpkg.com/feather-icons"></script>

    <!-- Style -->
    <link rel="stylesheet" href="<?php echo e(asset('style-search.css')); ?>" />
    <title>Search</title>
</head>

<body>

    <a href="<?php echo e(route('home.index')); ?>">
        <span class="close">&times;</span>
    </a>
    <section id="job-list" class="job-list">
	<!-- company/job_list.blade.php -->



        <form method="post" action="<?php echo e(route('search.post')); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="box">
                <input type="search" id="search" name="slugs" placeholder=" klik disini untuk mencari . . ." />
                <a href="#">
                    <button type="submit">search</button>
                </a>
            </div>

        </form>
    </section>

    <!-- my javascript -->
    <script src="javascript/script.js"></script>

    <!-- Feather Icons-->
    <script>
        feather.replace();
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel_job_portal\resources\views/search.blade.php ENDPATH**/ ?>