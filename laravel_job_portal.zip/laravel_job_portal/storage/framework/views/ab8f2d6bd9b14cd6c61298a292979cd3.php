<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" /> 
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/jobfable/company/buka_lowongan_kerja.css')); ?>" />
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
  
    <title>Open Job Vacancies</title>
</head>

<body>
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
      <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        <?php if($is_user==1): ?>
            <a id="ja_list" href="<?php echo e(route('jobapplication.list')); ?>">Riwayat Lamaran</a>
            <a id="j_detail" href="<?php echo e(route('jobapplication.detail')); ?>">Daftar Pekerjaan</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <a id="js_bookmark" href="<?php echo e(route('jobapplication.bookmarklist')); ?>">Tinjau Ulang</a>
        <?php elseif($is_user==2): ?>
            <a id="j_list" href="<?php echo e(route('job.list')); ?>">Buka Lowongan Kerja</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <?php endif; ?>
            <?php if(! $is_user): ?>               
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            <?php endif; ?>
        </div>
        <div class="navbar-extra">
             <?php if($is_user==1): ?>
             <a href="<?php echo e(route('jobapplication.detail')); ?>" id="search"><i data-feather="search"></i></a>
            <a href="<?php echo e(route('jobseeker.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>
            <?php elseif($is_user==2): ?>
            <a href="<?php echo e(route('search.index')); ?>" id="search"><i data-feather="search"></i></a>  
            <a href="<?php echo e(route('company.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>            
            <?php endif; ?>
        </div>
    </nav>
    </header>
    <!-- navbar end -->
    <!-- Buka Lowongan Kerja start -->
    <main>
        <h1>Buka Lowongan Kerja</h1>
        <div class="button-buat-lowongan">
            <a class="card-btn btn btn-primary p-2" href="<?php echo e(route('job.view')); ?>" role="button">Buat Lowongan Pekerjaan</a>
        </div>
        <section class="buka-lowongan-kerja">
             <table id="open_job_vacancy" class="table table-bordered table-hover">
                <thead class="table-awal bg-primary">
                    <tr>
                        <th scope="col">Nomor</th>
                        <th scope="col">Posisi Pekerjaan</th>
                        <th scope="col">Daftar Pelamar</th>
                        <th scope="col">Tanggal Dibuat</th>
                        <th scope="col"></th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody class="table-group-divider">
                    <?php $no=1; ?>
                    <?php if($listJob): ?>
                    <?php $__currentLoopData = $listJob; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($no++); ?></th>
                        <td><a href="<?php echo e(route('job.get',['id' => $list->id])); ?>">   <?php echo e($list->name); ?></a>
                         </td>
                        <td><a class="tombol" href="<?php echo e(route('jobapplication.companylist',['id'=>$list->id])); ?>">Pelamar</a></td>
                        <td><?php echo e(date('Y-m-d', strtotime($list->created_at))); ?></td>
                        <td>
                        <?php if($list->is_active == true): ?>
                            
                        <a class="tombol" href="<?php echo e(route('job.edit',['id'=>$list->id])); ?>">Edit</a>
                        <?php endif; ?>
                        </td>
                        <td> 
                            <?php if($list->is_active == true): ?>                          
                            <a class="form-control" id="delete-link" href="<?php echo e(route('job.delete',['id'=>$list->id])); ?>">Hapus</a>
                            <!-- Modal -->               
                            <?php endif; ?>             
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </section>
        <!-- <section class="tombol-page-lain d-flex justify-content-between">
            <a class="btn btn-primary" href="editprofilecompany.html">Sebelumnya</a>
            <div class="btn-group">
                <a href="#" class="btn btn-outline-primary active" aria-current="page">1</a>
                <a href="#" class="btn btn-outline-primary">2</a>
                <a href="#" class="btn btn-outline-primary">3</a>
            </div>
            <a class="btn btn-primary" href="editprofilecompany.html">Selanjutnya</a>
        </section> -->
        
    </main>
    <!-- Buka Lowongan Kerja End -->
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer End -->
    <script>
    feather.replace();

    </script>
    <script type="text/javascript">
    $(document).ready(function() {
        $("#delete-link").on("click", function(e) {
            e.preventDefault(); // Prevent the default click behavior of the link            
            Swal.fire({
                title: 'Hapus Lowongan Pekerjaan?',
                text: 'Lowongan pekerjaan akan dihapus secara permanen',
                showConfirmButton: true,
                showCancelButton: true,
                allowOutsideClick: false,
            }).then((result) => {
                if (result.isConfirmed) {
                    // User clicked "Confirm", proceed with the delete action
                    window.location.href = $(this).attr('href');
                } else {
                    // User clicked "Cancel", do nothing
                }
            });
        });
        $('#open_job_vacancy').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': false,
            'ordering': false,
            'info': false,
            'autoWidth': false
        });
    });
 

    </script>
</body>

</html>
<?php /**PATH D:\Downloads\laravel_job_portal (4)\laravel_job_portal\resources\views/company/buka_lowongan_kerja.blade.php ENDPATH**/ ?>