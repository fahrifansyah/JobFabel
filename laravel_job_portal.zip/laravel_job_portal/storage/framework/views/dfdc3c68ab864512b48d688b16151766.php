<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet">    
    <link href="<?php echo e(asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
    <script src="https://unpkg.com/feather-icons"></script>
     <link rel="stylesheet" href="<?php echo e(asset('assets/jobfable/user/style.css')); ?>" />
     
    <title>landing page</title>
    <style>
        
    </style>
</head>

<body>
    <!-- navbar start --> 
    <script src="<?php echo e(asset('assets/plugin/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script> 
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/feather-icons/feather.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')); ?>"></script>
      <script src="https://unpkg.com/feather-icons"></script>
    <nav class="navbar">
        <a href="<?php echo e(route('home.index')); ?>" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        <?php if($is_user==1): ?>
            <a id="ja_list" href="<?php echo e(route('jobapplication.list')); ?>">Riwayat Lamaran</a>
            <a id="j_detail" href="<?php echo e(route('jobapplication.detail')); ?>">Daftar Pekerjaan</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <a id="js_bookmark" href="<?php echo e(route('jobapplication.bookmarklist')); ?>">Tinjau Ulang</a>
        <?php elseif($is_user==2): ?>
            <a id="j_list" href="<?php echo e(route('job.list')); ?>">Buka Lowongan Kerja</a>
            <a href="<?php echo e(route('company.about')); ?>">Seputar Kerja</a>  
            <?php endif; ?>
            <?php if(! $is_user): ?>               
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            <?php endif; ?>
        </div>
        <div class="navbar-extra">
             <?php if($is_user==1): ?>
             <a href="<?php echo e(route('jobapplication.detail')); ?>" id="search"><i data-feather="search"></i></a>
            <a href="<?php echo e(route('jobseeker.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>
            <?php elseif($is_user==2): ?>
            <a href="<?php echo e(route('search.index')); ?>" id="search"><i data-feather="search"></i></a>  
            <a href="<?php echo e(route('company.index')); ?>" id="profil"><i data-feather="user"></i></a>
            <a href="<?php echo e(route('logout')); ?>" id="logout"><i data-feather="log-out"></i></a>            
            <?php endif; ?>
        </div>
    </nav>
    <!-- hero selection start -->
    <section class="hero" id="home">
        <main class="content">
            <h1>Kami Menyediakan Lowongan Pekerjaan!</h1>
            <p>Khusus Disabilitas Sensorik</p>
            
        </main>
        <div class="wrapper">
            <div class="form-box login modal" id="masuk" style="display:none;">
                <h2>Login</h2>
                <form method="post" action="<?php echo e(route('login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="login_username" required />
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="key"></i></span>
                        <input type="password" name="login_password" required />
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <a href="#lupa" rel="modal:open">Lupa Password</a>
                    </div>
                    <button type="submit" class="btn">Masuk</button>
                    <div class="login-register">
                        <p>Belum Punya Akun? <a href="#daftar-user" rel="modal:open">Daftar</a></p>
                    </div>
                </form>
            </div>
            <!-- register User #1 start -->
            <form id="daftar-user" method="post" action="<?php echo e(route('register.jobseeker')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div id="daftar-user-1" class="form-box register">
                    <h2>Pendaftaran Pencari Kerja #1</h2>
                    <div class="login-register">
                        <p>Ingin Beralih ke pendaftaran Perusahaan? <a href="#daftar-company" rel="modal:open">Klik disini</a></p>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="job_seeker_name" />
                        <label>Nama</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="job_seeker_username" required />
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input type="text" name="job_seeker_email" required />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="password" name="job_seeker_password" />
                        <label>Password</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="password" name="job_seeker_confirm_password" />
                        <label>Konfirmasi Password</label>
                    </div>
                    <a><button type="button" id="daftar-user-toggle" class="btn" >Selanjutnya</button></a>
                </div>
                <!-- daftar User #2 start -->
                <div id="daftar-user-2" class="form-box register" style="display:none;">
                    <h2>Pendaftaran Pencari Kerja #2</h2>
                    <div class="login-register">
                        <p>Ingin Beralih ke pendaftaran company? <a href="#daftar-company" rel="modal:open">Klik disini</a></p>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="date" name="job_seeker_dob" />
                        <label>Tanggal Lahir</label>
                    </div>
                    <div class="input-box">
                        <select name="gender" id="gender">
                            <option value="select">Pilih</option>
                            <option value="male">Laki-laki</option>
                            <option value="female">Perempuan</option>
                        </select>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="job_seeker_phone" />
                        <label>No. Telp</label>
                    </div>
                    <div >
                        <label>Jenis Disabilitas</label><br>
                        <span class="icon"><i data-feather="user"></i></span>
                        <label>
                            <input type="checkbox" class="form-control" name="job_seeker_disability[]" value="Tuna netra">
                            Tuna netra
                        </label><br>
                        <label>
                            <input type="checkbox" class="form-control" name="job_seeker_disability[]" value="Tuna rungu">
                            Tuna rungu
                        </label><br>
                        <label>
                            <input type="checkbox" class="form-control" name="job_seeker_disability[]" value="Tuna wicara">
                            Tuna wicara
                        </label><br>
                        <label>
                            <input type="checkbox" class="form-control" name="job_seeker_disability[]" value="Tuna haptic/Tuna kinestetik">
                            Tuna haptic/Tuna kinestetik
                        </label><br>
                    </div>
                    <label for=""></label>
                    
                    
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="job_seeker_experience" />
                        <label>Kemampuan</label>
                    </div>
                    <div class="profil-pic">
                        <label for="profil-pic">Upload Foto Profil</label>
                        <input type="file" id="imageUpload" name="job_seeker_image">
                        <span class="validity"></span>
                    </div>
                    <div class="profil-pic">
                        <label for="profil-pic">Upload CV</label>
                        <input type="file" id="fileUpload" name="job_seeker_file" accept="image/*">
                    </div>
                    <div class="login-register">
                        <button type="submit" class="btn">Daftar</button>
                    </div>
                </div>
            </form>
           
            <!-- register Company end -->
            <form id="daftar-company" method="post" action="<?php echo e(route('register.company')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-box register">
                    <h2>Pendaftaran Perusahaan</h2>
                    <div class="login-register">
                        <p>Ingin Beralih ke pendaftaran Pencari Kerja ? <a href="#daftar-user" rel="modal:open">Klik disini</a></p>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_name" />
                        <label>Nama Perusahaan</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_username" />
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input type="text" name="company_email" />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_description" />
                        <label>Deskripsi</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_address" />
                        <label>Alamat</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input type="text" name="company_phone" />
                        <label>No. Telp</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_website" />
                        <label>Website</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" name="company_category" />
                        <label>Jenis Perusahaan</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input type="text" name="company_language" />
                        <label>Bahasa </label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="password" name="company_password" />
                        <label>Password</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="password" name="company_confirm_password" />
                        <label>Konfirmasi Password</label>
                    </div>
                    <div class="profil-pic">
                        <label for="profil-pic">Upload Foto</label>
                        <input type="file" name="company_image" accept="image/*">
                    </div>
                    <button type="submit" class="btn">Daftar</button>
                </div>
            </form>
            <!-- forgot form start -->
            <div id="lupa" class="form-box register">
                <h2>Lupa Password</h2>
                 <form method="post" action="<?php echo e(route('validate')); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input name="email" type="email" />
                        <label>Email</label>
                    </div>
                    <button type="submit" class="btn">Kirim</button>
                </form>
            </div>
        </div>
        </div>
        <!-- loginform end -->
    </section>
    <!-- hero selection end -->
    <!-- About Section Start -->
    <section id="about" class="about">
        <h2><span>Tentang Kami</span></h2>
        <div class="row">
            <div class="about-img">
                <img src="<?php echo e(asset('assets/img/tentang_kami.jpg')); ?>" alt="Tentang Kami" />
            </div>
            <div class="content">
                <h3>Selamat datang di Job Portal untuk Orang dengan Disabilitas Sensorik!</h3>
                <p>Kami adalah platform online yang didedikasikan untuk membantu orang dengan disabilitas sensorik mencari pekerjaan yang cocok dengan keterampilan, keinginan, dan kebutuhan mereka.</p>
                <p>
                    Kami menyadari bahwa orang dengan disabilitas, terutama disabilitas sensorik seringkali menghadapi tantangan unik dalam mencari pekerjaan. Oleh karena itu, misi kami adalah untuk memberikan informasi pekerjaan bagi orang dengan disabilitas sensorik agar
                    mendapatkan pekerjaan yang sesuai dengan kebutuhan. Kami juga memberikan layanan ilmu pengetahuan mengenai pengembangan diri di dunia kerja secara gratis untuk penyandang disabilitas sensorik dan perusahaan. Kami berusaha membantu anda sukses meraih karir yang diinginkan.
                </p>
            </div>
        </div>
    </section>
    <!-- About Section End -->
    <!-- menuselection Start -->
  <!-- About Section Start -->
>
  <!--  Start -->
  <section id="listcompany" class="listcompany">
    <h2><span>FAQ</span></h2>
    <div class="container-faq">
      <div class="container-1">
        <div class="question">
          <h3>Apa Tujuan Dari Website Ini?</h3>
        </div>
        <div class="answer">
          <p>
            Website ini didirikan dengan tujuan untuk menyediakan informasi tentang lowongan pekerjaan yang ramah terhadap orang dengan disabilitas sensorik. Kami ingin menciptakan kesempatan kerja yang inklusif dan mendukung kesetaraan peluang
            bagi individu dengan disabilitas sensorik.
          </p>
        </div>
      </div>
      <div class="container2">
        <div class="question2">
          <h3>Bagaimana cara kerja website ini?</h3>
        </div>
        <div class="answer2">
          <p>
            Kami menghubungkan perusahaan yang memiliki kebijakan inklusif dengan individu yang mencari pekerjaan. Anda dapat mencari lowongan pekerjaan yang sesuai dengan keahlian dan minat Anda serta mengirimkan lamaran melalui website
            kami.
          </p>
        </div>
      </div>
    </div>
  </section>
  <!--  end -->
    <!-- contact section end -->
    <!-- footer start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="<?php echo e(url('/')); ?>#home">Home</a>
          <a href="<?php echo e(url('/')); ?>#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer end -->
    <script>
    feather.replace();

    </script>
    <script>
<?php if($message = session('success')): ?>
Swal.fire(
  'Berhasil!',
  '<?php echo e($message); ?>',
  'success'
)
<?php endif; ?>
<?php if($message = session('error')): ?>
Swal.fire(
  'Gagal!',
  '<?php echo e($message); ?>',
  'error'
)
<?php endif; ?>
</script>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        const daftarUserToggle = document.getElementById("daftar-user-toggle");
        const daftarUser1 = document.getElementById("daftar-user-1");
        const daftarUser2 = document.getElementById("daftar-user-2");

        daftarUserToggle.addEventListener("click", function () {
            // Tombol "Selanjutnya" diklik, sembunyikan form #daftar-user-1 dan tampilkan form #daftar-user-2
            daftarUser1.style.display = "none";
            daftarUser2.style.display = "block";
        });
    });
</script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\laravel_job_portal\resources\views/user/landingpage.blade.php ENDPATH**/ ?>