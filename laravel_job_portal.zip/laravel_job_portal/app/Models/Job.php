<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Job extends Model
{
    use HasFactory;
    public $table = 'Job';
    protected $fillable = ['company_id','category_id','category','name','description','requirement','salary','city_id','city','operation','info','is_active','slugs','disability'];


    /**
     * Get the company that owns the Job
     *
     * @return \Illuminate\Database\Eloquent\Relations\BelongsTo
     */
    public function company(): BelongsTo
    {
        return $this->belongsTo(company::class, 'id', 'company_id');
    }
}
