<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class JobApplication extends Model
{
    use HasFactory;
    public $table = 'JobApplication';
    protected $fillable = ['job_id','jobseeker_id','company_id','name','dob','experience','phone','description','gender','address','disability','status','bookmark'];
}

