<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Company;
use App\Models\Job;
use App\Models\JobApplication;
use App\Models\JobSeeker;
use DB;

class JobApplicationController extends Controller
{
    public function search(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        $salary = ($request->salary != null) ? (' and  salary="' . $request->salary . '" ') : '';
        $disability = ($request->disability != null) ? (' and  disability="' . $request->disability . '" ') : '';
        $category = ($request->category != null) ? (' and  category="' . $request->category . '" ') : '';
        $city = ($request->city != null) ? (' and  city="' . $request->city . '" ') : '';
        $slugs = ($request->slugs != null) ? (' and slugs like "%' . $request->slugs . '%" ') : '';
        $listJob = [];
        $listSlugs = DB::select('select * from Job where 1 ' . $salary . $category . $city . $slugs);
        // dd($listSlugs);
        if (!empty($listSlugs)) {
            $listJob = DB::table('Job')
                ->select('Job.*', 'Company.id as c_id', 'Company.image', 'Company.name as c_name', 'Company.address','Company.phone','Company.language', 'Company.description as c_description','Company.category as c_category')
                ->leftJoin('Company', 'Company.id', '=', 'Job.company_id')
                ->where('Job.is_active', 1)
                ->whereIn('Job.id', array_column($listSlugs, 'id'))
                ->get();
            // dd($listJob);
        }
        

        if ($is_user == 1) {
            return  view('user.job_list', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJob]);
        }
    }
    public function companyApplicationList(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        if ($is_user == 2) {
            $company = Company::select('*')->where('user_id', $user_id)->first();
            $listJobAplication = DB::select('select JobApplication.*,Company.id as c_id,Company.image,Company.name as c_name,Company.address, JobSeeker.id as js_id, JobSeeker.user_id as js_user_id, JobSeeker.name as js_name, JobSeeker.file from JobApplication left join Company on Company.id = JobApplication.company_id  left join JobSeeker on JobSeeker.id = JobApplication.jobseeker_id where Company.id = "' . $company->id . '" and JobApplication.job_id="' . $id . '" and JobApplication.status !=""');
            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('list_company_application',['listJobAplication'=>$listJobAplication])
                    .view('footer');*/
            return  view('company.daftar_pelamar', ['username' => $username, 'is_user' => $is_user, 'listJobAplication' => $listJobAplication]);
        }
    }
    public function myApplication(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';


        //dd($listJobAplication);
        if ($is_user == 1) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';

            $listJobAplication = JobApplication::select('*')->where('job_id', $id)->where('jobseeker_id', $jobseeker_id)->first();
            $listJob = DB::select('select Job.*,Company.id as c_id,Company.image,Company.name as c_name,Company.address, Company.phone,Company.language,Company.description as c_description,Company.category as c_category, Company.website from Job left join Company on Company.id = Job.company_id  where Job.is_active = 1 and Job.id="' . $id . '"');
            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('apply_job',['listJob'=>$listJob, 'listJobAplication'=>$listJobAplication])
                    .view('footer');*/
            return  view('user.job_detail', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJob, 'listJobAplication' => $listJobAplication]);
        }
    }
    public function applicationDetail(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';


        if ($is_user == 1) {

            $listJob = DB::select('select Job.*,Company.id as c_id,Company.image,Company.name as c_name,Company.phone,Company.address,Company.language, Company.description as c_description,Company.category as c_category from Job left join Company on Company.id = Job.company_id  where Job.is_active = 1');
            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('job_detail',['listJob'=>$listJob])
                    .view('footer');*/
            return  view('user.job_list', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJob]);
        }
    }
    public function applyApplication(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
        $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';

        $listJobAplication = JobApplication::select('*')->where('job_id', $id)->where('jobseeker_id', $jobseeker_id)->first();
        $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
        $job = Job::select('*')->where('id', $id)->first();

        JobApplication::updateOrCreate(
            ["job_id" => $id, 'jobseeker_id' => $jobseeker_id],
            [
                "company_id"    => ($job->company_id != null) ? $job->company_id : '',
                "name"          => ($job->name != null) ? $job->name : '',
                "dob"           => ($jobseeker->dob != null) ? $jobseeker->dob : '',
                "experience"    => ($jobseeker->experience != null) ? $jobseeker->experience : '',
                "phone"         => ($jobseeker->phone != null) ? $jobseeker->phone : '',
                "description"   => ($jobseeker->description != null) ? $jobseeker->description : '',
                "gender"        => ($jobseeker->gender != null) ? $jobseeker->gender : '',
                "address"       => ($jobseeker->address != null) ? $jobseeker->address : '',
                "disability"    => ($jobseeker->disability != null) ? $jobseeker->disability : '',
                "status"        => 'menunggu',
                "bookmark"      => '-'
            ]
        );
        return back()->with('error', 'Data Tidak Berhasil !.');
    }

    public function myApplicationList(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';



        /*$listJobAplication = JobApplication::select('*')->where('jobseeker_id',$user_id)->get();*/

        if ($is_user == 1) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';

            $listJobAplication = DB::select('select JobApplication.*,Company.id as c_id,Company.image,Company.name as c_name,Company.address, Company.phone,Company.address,Company.language, Company.description as c_description,Company.category as c_category from JobApplication left join Company on Company.id = JobApplication.company_id  where JobApplication.jobseeker_id = "' . $jobseeker_id . '" and JobApplication.status !=""');
            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('list_myapplication',['listJobAplication'=>$listJobAplication])
                    .view('footer');*/
            return  view('user.history', ['username' => $username, 'is_user' => $is_user, 'listJobAplication' => $listJobAplication]);
        }
    }

    public function bookmarkApplication(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
        $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';
        $job = Job::select('*')->where('id', $id)->first();
        $listJobAplication = JobApplication::select('*')->where('job_id', $id)->where('jobseeker_id', $jobseeker_id)->first();

          if($listJobAplication){
            if($listJobAplication->bookmark == '-'){
    
                JobApplication::updateOrCreate(
                    ["job_id" => $id, 'jobseeker_id' => $jobseeker_id],
                    [
                        "company_id"    => ($job->company_id != null) ? $job->company_id : '',
                        "name"          => ($job->name != null) ? $job->name : '',
                        "dob"           => ($jobseeker->dob != null) ? $jobseeker->dob : '',
                        "experience"    => ($jobseeker->experience != null) ? $jobseeker->experience : '',
                        "phone"         => ($jobseeker->phone != null) ? $jobseeker->phone : '',
                        "description"   => ($jobseeker->description != null) ? $jobseeker->description : '',
                        "gender"        => ($jobseeker->gender != null) ? $jobseeker->gender : '',
                        "address"       => ($jobseeker->address != null) ? $jobseeker->address : '',
                        "disability"    => ($jobseeker->disability != null) ? $jobseeker->disability : '',
                        "status"        => (isset($listJobAplication->status)) ? $listJobAplication->status : '',
                        "bookmark"      => 'bookmarked'
                    ]
                );
            }elseif($listJobAplication->bookmark == 'bookmarked'){
                JobApplication::updateOrCreate(
                    ["job_id" => $id, 'jobseeker_id' => $jobseeker_id],
                    [
                        "company_id"    => ($job->company_id != null) ? $job->company_id : '',
                        "name"          => ($job->name != null) ? $job->name : '',
                        "dob"           => ($jobseeker->dob != null) ? $jobseeker->dob : '',
                        "experience"    => ($jobseeker->experience != null) ? $jobseeker->experience : '',
                        "phone"         => ($jobseeker->phone != null) ? $jobseeker->phone : '',
                        "description"   => ($jobseeker->description != null) ? $jobseeker->description : '',
                        "gender"        => ($jobseeker->gender != null) ? $jobseeker->gender : '',
                        "address"       => ($jobseeker->address != null) ? $jobseeker->address : '',
                        "disability"    => ($jobseeker->disability != null) ? $jobseeker->disability : '',
                        "status"        => (isset($listJobAplication->status)) ? $listJobAplication->status : '',
                        "bookmark"      => '-'
                    ]
                );
    
            }
        }else{
            JobApplication::updateOrCreate(
                ["job_id" => $id, 'jobseeker_id' => $jobseeker_id],
                [
                    "company_id"    => ($job->company_id != null) ? $job->company_id : '',
                    "name"          => ($job->name != null) ? $job->name : '',
                    "dob"           => ($jobseeker->dob != null) ? $jobseeker->dob : '',
                    "experience"    => ($jobseeker->experience != null) ? $jobseeker->experience : '',
                    "phone"         => ($jobseeker->phone != null) ? $jobseeker->phone : '',
                    "description"   => ($jobseeker->description != null) ? $jobseeker->description : '',
                    "gender"        => ($jobseeker->gender != null) ? $jobseeker->gender : '',
                    "address"       => ($jobseeker->address != null) ? $jobseeker->address : '',
                    "disability"    => ($jobseeker->disability != null) ? $jobseeker->disability : '',
                    "status"        => (isset($listJobAplication->status)) ? $listJobAplication->status : '',
                    "bookmark"      => '-'
                ]
            );
        }
        return back()->with('error', 'Data Tidak Berhasil !.');
    }

    public function bookmarkApplicationList(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';



        if ($is_user == 1) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';
            $listJobAplication = DB::select('select JobApplication.*,Company.id as c_id,Company.image,Company.name as c_name,Company.address,Company.phone,Company.address,Company.language, Company.description as c_description,Company.category as c_category from JobApplication left join Company on Company.id = JobApplication.company_id  where JobApplication.jobseeker_id = "' . $jobseeker_id . '" and JobApplication.bookmark !=""');

            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('list_bookmark',['listJobAplication'=>$listJobAplication])
                    .view('footer');*/
            return  view('user.bookmark', ['username' => $username, 'is_user' => $is_user, 'listJobAplication' => $listJobAplication]);
        }
    }

    public function deleteBookmark(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        JobApplication::updateOrCreate(
            ["job_id" => $id],
            [
                "bookmark"        => ''
            ]
        );
        return back()->with('error', 'Data Tidak Berhasil !.');
    }

    public function confirm(Request $request, $id, $status, $jobseeker_id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';
        $company = Company::select('*')->where('user_id', $user_id)->first();

        JobApplication::updateOrCreate(
            ["job_id" => $id, "jobseeker_id" => $jobseeker_id, "company_id" => $company->id],
            [
                "status" => $status
            ]
        );
        return back()->with('error', 'Data Tidak Berhasil !.');
    }

    public function viewProfile(Request $request,$id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';
        $jobseeker = JobSeeker::select('*')->where('user_id', $id)->first();

        // dd($jobseeker);
        /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('profil_job_seeker',['jobseeker'=>$jobseeker]).view('footer');*/
        return view('company.profil_user', ['username' => $username, 'is_user' => $is_user, 'jobseeker' => $jobseeker]);
    }
}
