<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    public function profile(){}
    public function password(){}
    public function update_password(){}
    public function update(){}
}
