<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\JobSeeker;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;

class JobSeekerController extends Controller
{
    public function index(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';


        if ($is_user == 1) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('profil_job_seeker',['jobseeker'=>$jobseeker]).view('footer');*/
           
            return view('user.profil_user', ['username' => $username, 'is_user' => $is_user, 'jobseeker' => $jobseeker]);
        }
    }
    public function edit(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';

        if ($is_user == 1) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            $user = User::select('*')->where('id', $user_id)->where('username', $username)->first();
            // Mengatur pesan dan flag pada session
            Session::flash('sweetAlertMessage', 'Hello from server!');
            Session::flash('showSweetAlert', true);
            $selectedDisabilities = explode(',', $jobseeker->disability);

            // dd($selectedDisabilities);
            /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('edit_profil_job_seeker',['jobseeker'=>$jobseeker,'user'=>$user]).view('footer');*/
            return view('user.edit_profil', ['username' => $username, 'is_user' => $is_user, 'jobseeker' => $jobseeker, 'user' => $user,'selectedDisabilities' => $selectedDisabilities]);
        }
    }
    public function update(Request $request)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';
        $selectedDisabilities = implode(',', $request->input('disability'));
        if (isset($request->jobseeker_id)) {
            $jobseeker = JobSeeker::select('*')->where('user_id', $user_id)->first();
            $imageName = ($jobseeker->image != null) ? $jobseeker->image : '';
            $fileName = ($jobseeker->file != null) ? $jobseeker->file : '';
            $user = User::select('*')->where('id', $user_id)->where('username', $username)->first();
            if ($request->hasFile('job_seeker_file')) {
                $file = $request->file('job_seeker_file');
                $destinationPath = public_path('uploads');
                $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($destinationPath, $fileName);
            }
            if ($request->hasFile('job_seeker_image')) {
                $file = $request->file('job_seeker_image');
                $destinationPath = public_path('uploads');
                $imageName = uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($destinationPath, $imageName);
            }
            if ($request->jobseeker_password != null) {
                User::updateOrCreate(
                    ["id" => $user_id],
                    [
                        "username"  => ($request->jobseeker_username != null) ? $request->jobseeker_username : $user->username,
                        "email"  => ($request->jobseeker_email != null) ? $request->jobseeker_email : $user->email,
                        "password"  => $request->jobseeker_password,
                        "is_user"   => 1
                    ]
                );
            } else {
                User::updateOrCreate(
                    ["id" => $user_id],
                    [
                        "username"  => ($request->jobseeker_username != null) ? $request->jobseeker_username : $user->username,
                        "email"  => ($request->jobseeker_email != null) ? $request->jobseeker_email : $user->email,
                        "is_user"   => 1
                    ]
                );
            }

            JobSeeker::updateOrCreate(
                ["user_id" => $user_id, 'id' => $request->jobseeker_id],
                [
                    "gender"      => ($request->jobseeker_gender != null) ? $request->jobseeker_gender : $jobseeker->gender,
                    "name"          => ($request->jobseeker_name != null) ? $request->jobseeker_name : $jobseeker->name,
                    "dob"   => ($request->jobseeker_dob != null) ? $request->jobseeker_dob : $jobseeker->dob,
                    "experience"   => ($request->jobseeker_experience != null) ? $request->jobseeker_experience : $jobseeker->experience,
                    "education"        => ($request->jobseeker_education != null) ? $request->jobseeker_education : $jobseeker->education,
                    "address"          => ($request->jobseeker_address != null) ? $request->jobseeker_address : $jobseeker->address,
                    "disability"          => ( $selectedDisabilities != null) ?  $selectedDisabilities : $jobseeker->disability,
                    "phone"          => ($request->jobseeker_phone != null) ? $request->jobseeker_phone : $jobseeker->phone,
                    "description"          => ($request->jobseeker_description != null) ? $request->jobseeker_description : $jobseeker->description,
                    "image"     => $imageName,
                    "file"     => $fileName
                ]
            );
            return redirect()->route('jobseeker.index')->with('success', 'Data Berhasil di Update!.');
        } else {

            return back()->with('error', 'Data Tidak Berhasil !.');
        }
    }
    public function store()
    {
    }
}
