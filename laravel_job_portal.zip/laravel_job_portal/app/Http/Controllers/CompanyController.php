<?php

namespace App\Http\Controllers; 

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Company;
use App\Models\JobSeeker;

class CompanyController extends Controller{
    public function index(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        //$is_user = Auth::user()-> $is_user;
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):0;  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  
        // dd($user_id);
        if ($is_user==2) {
            $company = Company::select('*')->where('user_id',$user_id)->first();
            //dd($company);
            return view('company.profil_company', ['username' => $username,'is_user'=> $is_user,'company'=>$company]);
        }
    }
    public function edit(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):0;  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        if ($is_user==2) {
            $company = Company::select('*')->where('user_id',$user_id)->first();
            $user = User::select('*')->where('id',$user_id)->where('username',$username)->first();
            //dd($company);
            /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('edit_profil_company',['company'=>$company,'user'=>$user]).view('footer');*/
            return view('company.edit_profil_company', ['username' => $username,'is_user'=> $is_user,'company'=>$company,'user'=>$user]);
        }
    }
    public function update(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        if(isset($request->company_id)){
            $company = Company::select('*')->where('user_id',$user_id)->first();
            $imageName = ($company->image !=null)?$company->image:'';
            $user = User::select('*')->where('id',$user_id)->where('username',$username)->first();
            if ($request->hasFile('company_image')) {
                $file = $request->file('company_image');
                $destinationPath = public_path('uploads');
                $imageName = uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($destinationPath, $imageName);
            }
            if($request->company_password !=null){
                User::updateOrCreate(
                ["id" => $user_id],
                [
                    "username"  => ($request->company_username !=null)? $request->company_username:$user->username,
                    "email"  => ($request->company_email !=null)? $request->company_email:$user->email,
                    "password"  => $request->company_password,
                    "is_user"   => 2
                ]); 
            }else{
                User::updateOrCreate(
                ["id" => $user_id],
                [
                    "username"  => ($request->company_username !=null)? $request->company_username:$user->username,
                    "email"  => ($request->company_email !=null)? $request->company_email:$user->email,                  
                    "is_user"   => 2
                ]); 
            } 
            
            Company::updateOrCreate(
                ["user_id" => $user_id,'id'=>$request->company_id],
                [                    
                    "category"      => ($request->company_category !=null)? $request->company_category:$company->category,
                    "name"          => ($request->company_name !=null)? $request->company_name:$company->name,
                    "description"   => ($request->company_description !=null)? $request->company_description:$company->description,
                    "address"   => ($request->company_address !=null)? $request->company_address:$company->address,
                    "phone"        => ($request->company_phone !=null)? $request->company_phone:$company->phone,
                   "website"          => ($request->company_website !=null)? $request->company_website:$company->website,
                    "language"          => ($request->company_language !=null)? $request->company_language:$company->language,
                    "image"     => $imageName 
                ]);
            return redirect()->route('company.index')->with('success', 'Data Berhasil di Update !.');      
        }else{
            return back()->with('error', 'Data Gagal Update !.');    
        }         
    }
    public function about(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('company.seputarkerja',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    /*public function registration(Request $request){}*/
    public function kontencompany1(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-company-1',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    public function kontencompany2(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-company-2',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    public function kontencompany3(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-company-3',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    public function kontenjobseeker1(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-jobseeker-1',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    public function kontenjobseeker2(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-jobseeker-2',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    public function kontenjobseeker3(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $company = Company::all();
        $jobseeker = JobSeeker::all();
        //dd($company);
        /*return view('header',['username' => $username,'is_user'=> $is_user]).view('about',['company'=>$company]).view('footer'); */
        return view('about.konten-jobseeker-3',['username' => $username,'is_user'=> $is_user,'company'=>$company,'jobseeker'=>$jobseeker]); 
    }
    
}
