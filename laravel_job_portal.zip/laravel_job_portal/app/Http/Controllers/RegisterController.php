<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use App\Models\JobSeeker;
use App\Models\Company;

class RegisterController extends Controller
{
    public function showRegistrationForm(){}
    public function registerCompany(Request $request){

        if ($request->hasFile('company_image')) {
            $file = $request->file('company_image');
            $destinationPath = public_path('uploads');
            $imageName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $imageName);
        }
        $data = [
            "name" => ($request->company_name !=null)? $request->company_name:'',
            "username" => ($request->company_username !=null)? $request->company_username:'',
            "email" => ($request->company_email !=null)? $request->company_email:'',
            "description" => ($request->company_description !=null)? $request->company_description:'',
            "address" => ($request->company_address !=null)? $request->company_address:'',
            "phone" => ($request->company_phone !=null)? $request->company_phone:'',
            "website" => ($request->company_website !=null)? $request->company_website:'',
            "password" => ($request->company_password !=null)? $request->company_password:'',
            "confirm_password" => ($request->company_confirm_password !=null)? $request->company_confirm_password:'',
            "category" => ($request->company_category !=null)? $request->company_category:'',
            "language" => ($request->company_language !=null)? $request->company_language:'',
             "image" => ($imageName !=null)? $imageName:'',
        ];
        
        $cekUser = User::where('username', $data['username'])->orWhere('email', $data['email'])->first();
        if($cekUser||($data['password']!==$data['confirm_password'])||($data['username']=='')||($data['password']=='')){
            return back()->with('error', 'Harap periksa data anda kembali!.');            
        }else{       
            User::updateOrCreate(
                ["username" => $data['username'],'email'=>$data['email']],
                [
                    "password"  => $data['password'],
                    "is_user"   => 2
                ]); 
        }        
        $user = User::select('id')->where('username', $data['username'])->orWhere('email', $data['email'])->first();
        if(isset($user->id)){
            Company::updateOrCreate(
                ["user_id" => $user->id],
                [
                    "name"          => $data['name'],
                    "description"   => $data['description'],
                    "address"       => $data['address'],
                    "phone"         => $data['phone'],
                    "website"       => $data['website'],
                    "category"      => $data['category'],
                    "language"      => $data['language'],
                    "image"         => $data['image']
                ]);
        }
        return back()->with('success', 'Data Berhasil !.');       
    }
    public function registerJobSeeker(Request $request){
        $selectedDisabilities = implode(',', $request->input('job_seeker_disability'));
        if ($request->hasFile('job_seeker_file')) {
            $file = $request->file('job_seeker_file');
            $destinationPath = public_path('uploads');
            $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $fileName);
        }
        if ($request->hasFile('job_seeker_image')) {
            $file = $request->file('job_seeker_image');
            $destinationPath = public_path('uploads');
            $imageName = uniqid() . '.' . $file->getClientOriginalExtension();
            $file->move($destinationPath, $imageName);
        }
        $data = [
            "name" => ($request->job_seeker_name !=null)? $request->job_seeker_name:'',
            "dob" => ($request->job_seeker_dob !=null)? $request->job_seeker_dob:'',
            "gender" => ($request->job_seeker_gender !=null)? $request->job_seeker_gender:'',
            "username" => ($request->job_seeker_username !=null)? $request->job_seeker_username:'',
            "email" => ($request->job_seeker_email !=null)? $request->job_seeker_email:'',
            "phone" => ($request->job_seeker_phone !=null)? $request->job_seeker_phone:'',
            "disability" => ($selectedDisabilities !=null)? $selectedDisabilities:'',
            "experience" => ($request->job_seeker_experience !=null)? $request->job_seeker_experience:'',
            "education" => ($request->job_seeker_education !=null)? $request->job_seeker_education:'',
            "address" => ($request->job_seeker_address !=null)? $request->job_seeker_address:'',
            "description" => ($request->job_seeker_description !=null)? $request->job_seeker_description:'',
            "password" => ($request->job_seeker_password !=null)? $request->job_seeker_password:'',
            "confirm_password" => ($request->job_seeker_confirm_password !=null)? $request->job_seeker_confirm_password:'',           
            "image" => ($imageName !=null)? $imageName:'',
            "file" => ($fileName !=null)? $fileName:''
        ];
        
        $cekUser = User::where('username', $data['username'])->orWhere('email', $data['email'])->first();
        if($cekUser||($data['password']!==$data['confirm_password'])||($data['username']=='')||($data['password']=='')){
            return back()->with('error', 'Harap periksa data anda kembali!.');            
        }else{       
            User::updateOrCreate(
                ["username" => $data['username'],'email'=>$data['email']],
                [
                    "password"  => $data['password'],
                    "is_user"   => 1
                ]); 
        }        
        $user = User::select('*')->where('username', $data['username'])->orWhere('email', $data['email'])->first();
        if(isset($user->id)){
            JobSeeker::updateOrCreate(
                ["user_id" => $user->id],
                [
                    "name"      => $data['name'],
                    "dob"       => $data['dob'],
                    "gender"    => $data['gender'],                    
                    "phone"     => $data['phone'],
                    "disability"=>$data['disability'],
                    "experience"=> $data['experience'],                    
                    "image"             =>$data['image'],
                    "education" => $data['education'],
                    "address" => $data['address'],
                    "description" =>$data['description'],
                    "image"         => $data['image'],
                    "file"         => $data['file']
                ]);

            
        }
        
        return back()->with('success', 'Data Berhasil !.');       
    }
    public function validate_email(Request $request){
        
        $data = ["email" => ($request->email !=null)? $request->email:''];
        $cekUser = User::Where('email', $data['email'])->first();
        
        if($cekUser){
            return back()->with('success', 'Data Terdaftar ! Silahkan kunjungi url '.url('/').'/registered_email/'.$cekUser->username);    
        }else{
            return back()->with('error', 'Data Tidak Terdaftar !.');       
        }        
    }

    public function forgot_password(Request $request){
        $data = ["id" => ($request->id !=null)? $request->id:''];
        $cekUser = User::Where('id', $data['id'])->first();
        $data = [           
            "password" => ($request->password !=null)? $request->password:'',
            "confirm_password" => ($request->confirm_password !=null)? $request->confirm_password:'',
        ];

        if(($cekUser->id)&&($data['password'] == $data['confirm_password'])){
            User::updateOrCreate(
                ['id'=>$cekUser->id],
                [
                    "password"  => $data['password']
                    
                ]); 
        }        
        return redirect()->route('home.index')->with('success', 'Data Berhasil Update !');      
        

    }
    public function registered_email(Request $request,$str){
       
        $data = ["username" => ($str !=null)? $str:''];
        $cekUser = User::Where('username', $data['username'])->first();
        if($cekUser){
            return view('user.forgot_password',['id'=>$cekUser->id]);
        }else{
            return redirect()->route('home.index')->with('error', 'Data Gagal !');      
        }
        
    }
   /*     
    public function create(){}*/
}
