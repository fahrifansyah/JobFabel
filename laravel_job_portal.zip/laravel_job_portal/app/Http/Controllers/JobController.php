<?php

namespace App\Http\Controllers;

use App\Models\Job;
use App\Models\User; 
use App\Models\Company;
use App\Models\JobSeeker;
use Illuminate\Http\Request;
use App\Models\JobApplication;
use Illuminate\Support\Facades\DB;

class JobController extends Controller
{
    
    public function list(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        

        //dd(auth()->user()->id);
        if ($is_user==2) {
            $listCompany = Company::select('*')->where('user_id',$user_id)->first();
        $listJob =  ($listCompany)? Job::select('*')->where('company_id',$listCompany->id)->get():'';
            /*return view('inc.header', ['username' => $username,'is_user'=> $is_user]).view('page.open_job_vacancy',['listJob'=>$listJob]).view('inc.footer');*/
            return view('company.buka_lowongan_kerja', ['username' => $username,'is_user'=> $is_user,'listJob'=>$listJob]);
        }
    }
    public function view(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        if ($is_user==2) {
            /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('add_job_vacancy').view('footer');*/
            return view('company.buat_lowongan_kerja', ['username' => $username,'is_user'=> $is_user]);

        }
    }
    public function add(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        $listCompany = Company::select('*')->where('user_id',$user_id)->first();
        $selectedDisabilities = implode(',', $request->input('disability'));
       if(($request->job_name !=null)&&isset($user_id)){
     
            $job = new Job;       
            $job->company_id = ($listCompany->id) ? $listCompany->id:'';
            $job->category_id = 0;
            $job->category = ($request->job_category !=null)? $request->job_category:'';
            $job->name = ($request->job_name!=null)? $request->job_name:'';
            $job->description = ($request->job_description !=null)? $request->job_description:'';
            $job->requirement = ($request->job_requirement !=null)? $request->job_requirement:'';
            $job->salary = ($request->job_salary !=null)? $request->job_salary:'';
            $job->city_id = 0;
            $job->city = ($request->job_city !=null)? $request->job_city:'';
            $job->operation = ($request->job_operation !=null)? $request->job_operation:'';
            $job->info = ($request->job_info !=null)? $request->job_info:'';
            $job->disability = ($selectedDisabilities !=null)? $selectedDisabilities:'';
            $job->is_active = true;
            $job->slugs = $listCompany->name.' '.$job->category.' '.$job->name.' '.$job->description.' '.$job->requirement.' '.$job->salary.' '.$job->city.' '.$job->operation.' '.$job->info;
            $job->save();  
            return redirect()->route('job.list')->with('success', 'Data Berhasil di Tambahkan !.');           
        }else{
            return back()->with('error', 'Data Tidak Berhasil !.');    
        }         
        
    }
    public function edit(Request $request,$id){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        if ($is_user==2) {
            $listCompany = Company::select('*')->where('user_id',$user_id)->first();
            $listJob = Job::select('*')->where('company_id',$listCompany->id)->where('id',$id)->first();
            $selectedDisabilities = explode(',', $listJob->disability);

            /*return view('header', ['username' => $username,'is_user'=> $is_user]).view('edit_job_vacancy',['listJob'=>$listJob]).view('footer');*/
            return view('company.edit_lowongan_kerja', ['username' => $username,'is_user'=> $is_user,'listJob'=>$listJob,'selectedDisabilities' => $selectedDisabilities]);
        }
    }
    public function update(Request $request){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  
        $selectedDisabilities = implode(',', $request->input('disability'));
       
        if(isset($request->job_id)){
            $listCompany = Company::select('*')->where('user_id',$user_id)->first(); 
            $listJob = Job::select('*')->where('id',$request->job_id)->first(); 
            Job::updateOrCreate(
                ["company_id" => $listCompany->id,'id'=>$request->job_id],
                [
                    "category_id"   => 0,
                    "category"      => ($request->job_category !=null)? $request->job_category:$listJob->job_category,
                    "name"          => ($request->job_name !=null)? $request->job_name:$listJob->job_name,
                    "description"   => ($request->job_description !=null)? $request->job_description:$listJob->job_description,
                    "requirement"   => ($request->job_requirement !=null)? $request->job_requirement:$listJob->job_requirement,
                    "salary"        => ($request->job_salary !=null)? $request->job_salary:$listJob->job_salary,
                    "city_id"       => 0,
                    "city"          => ($request->job_city !=null)? $request->job_city:$listJob->job_city,
                    "operation"     => ($request->job_operation !=null)? $request->job_operation:$listJob->job_operation,
                    "info"          => ($request->job_info !=null)? $request->job_info:$listJob->job_info,
                    "disability"          => ($selectedDisabilities !=null)?  $selectedDisabilities:$listJob->disability,
                    "slugs"         => ($request->slugs !=null)? $request->slugs:$listJob->slugs,
                    "is_active"     => true,
                ]);
            return redirect()->route('job.list')->with('success', 'Data Berhasil di Update!.');       
        }else{
            return back()->with('error', 'Data Tidak Berhasil !.');    
        }         
        
    }
    public function delete(Request $request,$id){
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  


        if ($is_user==2) {
            $listCompany = Company::select('*')->where('user_id',$user_id)->first();
            $listJob = Job::select('*')->where('company_id',$listCompany->id)->where('id',$id)->first();
            if ($listJob) {    
                $listJob->is_active = false;
                $listJob->update();
            } 
            return redirect()->route('job.list')->with('error', 'Data Berhasil di hapus!.');    
        }
        return back()->with('error', 'Data Tidak Berhasil !.');    

    }


    public function myApplication(Request $request, $id)
    {
        $is_user = ($request->session()->get('is_user') != null) ? $request->session()->get('is_user') : '';
        // $user_id = ($request->session()->get('user_id') != null) ? $request->session()->get('user_id') : '';
        $username = ($request->session()->get('username') != null) ? $request->session()->get('username') : '';


        //dd($listJobAplication);
        if ($is_user == 2) {
            // $jobseeker = JobSeeker::select('*')->where('id', $id)->first();
            // $jobseeker_id = ($jobseeker->id != null) ? $jobseeker->id : '';
            $listJobAplication = JobApplication::select('*')->where('job_id', $id)->first();
            $listJob = DB::select('select Job.*,Company.id as c_id,Company.image,Company.name as c_name,Company.phone,Company.address,Company.language, Company.description as c_description,Company.category as c_category, Company.website from Job left join Company on Company.id = Job.company_id  where  Job.id="' . $id . '"');
            // dd($listJob);
            /*return  view('header', ['username' => $username,'is_user'=> $is_user])
                    .view('apply_job',['listJob'=>$listJob, 'listJobAplication'=>$listJobAplication])
                    .view('footer');*/
            return  view('company.job_detail', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJob, 'listJobAplication' => $listJobAplication]);
        }
    }
    
}

