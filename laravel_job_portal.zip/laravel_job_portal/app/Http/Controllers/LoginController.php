<?php

namespace App\Http\Controllers;


use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Str;
use App\Models\User;

class LoginController extends Controller
{
    public function login(Request $request){      
        $credentials = [
            'username' => $request->login_username,
            'password' => $request->login_password
        ];   
        /*$cekUser = User::where('username', $credentials['username'])->first();
        $user = User::find($cekUser->id);
        Auth::login($user);
        $test = auth()->user();
        dd($test);*/
       /* Auth::attempt($credentials);
       $user = Auth::user(); 
       $test = auth()->user();
       dd($test);*/
        if (Auth::attempt($credentials)) {            
            $user = Auth::user();    
            $request->session()->put('user_id', $user->id);
            $request->session()->put('is_user', $user->is_user);  
            $request->session()->put('username', $user->username);  
            
            return redirect()->route('home.index')->with('success', 'Berhasil Login !.');      
        } else {
           return back()->with('error', 'Periksa data kembali !.');     
        }
      
    }

    public function logout(Request $request)
    {
        Auth::logout();        
        $request->session()->flush();
        return redirect('/');
    }  

    
}
