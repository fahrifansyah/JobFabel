<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Str;


class HomeController extends Controller
{
    public function index(Request $request){     
        $is_user = ($request->session()->get('is_user') !=null)?$request->session()->get('is_user'):'';
        $user_id = ($request->session()->get('user_id') !=null)?$request->session()->get('user_id'):'';  
        $username = ($request->session()->get('username') !=null)?$request->session()->get('username'):'';  

        /*if ($is_user==2) {
            return view('inc.header', ['username' => $username,'is_user'=> $is_user]).view('page.home').view('inc.footer');
        } elseif ($is_user==1) {
            return view('inc.header', ['username' => $username,'is_user'=> $is_user]).view('page.home').view('inc.footer');
        } else{
            return view('inc.header',['username' => $username,'is_user'=> $is_user]).view('page.landing').view('inc.footer'); 
        }*/
        
        
        return view('user.landingpage',['username' => $username,'is_user'=> $is_user]); 
       
    }

   
}
