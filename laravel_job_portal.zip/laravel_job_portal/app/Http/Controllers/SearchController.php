<?php

namespace App\Http\Controllers;

use App\Models\JobSeeker;
use Illuminate\Http\Request;
use App\Models\JobApplication;
use Illuminate\Support\Facades\DB;

class SearchController extends Controller
{
    public function index(){
        return view('search');
    }

    public function search(Request $request)
{
    $is_user = $request->session()->get('is_user', '');
    $user_id = $request->session()->get('user_id', '');
    $username = $request->session()->get('username', '');

    $listJobseeker = JobSeeker::where('name',$request->slugs)->get();
    if ($is_user == 2) {
        if (count($listJobseeker) > 0) {
            return view('company.job_list', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJobseeker]);
        } else {
            return view('company.job_list', ['username' => $username, 'is_user' => $is_user, 'listJob' => $listJobseeker])->withErrors('No job seekers found.');
        }
    }
}

}
