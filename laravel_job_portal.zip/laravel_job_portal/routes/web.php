<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\CompanyController;
use App\Http\Controllers\JobSeekerController;
use App\Http\Controllers\JobController;
use App\Http\Controllers\JobApplicationController;
use App\Http\Controllers\SearchController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
 
/*Route::get('/', function () {
    return view('welcome'); 
});*/
Route::get('/clear', function() {
    Artisan::call('cache:clear');
    Artisan::call('config:clear');
    Artisan::call('config:cache');
    Artisan::call('view:clear'); 
    Artisan::call('route:clear');   
    return "Cleared!";
});


Route::get('/test',                             [HomeController::class,'test'])->name('home.test'); 
Route::get('/',                                 [HomeController::class,'index'])->name('home.index'); 

Route::post('/login',                           [LoginController::class,'login'])->name('login'); 
Route::get('/logout',                           [LoginController::class,'logout'])->name('logout'); 

Route::post('/validate_email',                  [RegisterController::class,'validate_email'])->name('validate'); 
Route::post('/forgot_password',           [RegisterController::class,'forgot_password'])->name('forgot'); 
Route::get('/registered_email/{str}',                 [RegisterController::class,'registered_email'])->name('registered'); 
Route::post('/register_job_seeker',             [RegisterController::class,'registerJobSeeker'])->name('register.jobseeker'); 
Route::post('/register_company',                [RegisterController::class,'registerCompany'])->name('register.company'); 

Route::get('/jobseeker/profil',                 [JobSeekerController::class,'index'])->name('jobseeker.index'); 
Route::get('/jobseeker/edit',                   [JobSeekerController::class,'edit'])->name('jobseeker.edit'); 
Route::post('/jobseeker/update',                 [JobSeekerController::class,'update'])->name('jobseeker.update'); 

Route::get('/company/profil',                   [CompanyController::class,'index'])->name('company.index'); 
Route::get('/company/edit',                     [CompanyController::class,'edit'])->name('company.edit'); 
Route::post('/company/update',                   [CompanyController::class,'update'])->name('company.update'); 
Route::get('/company/about',                         [CompanyController::class,'about'])->name('company.about');
Route::get('konten-company-1', [CompanyController::class,'kontencompany1'])->name('konten-company-1');
Route::get('konten-company-2', [CompanyController::class,'kontencompany2'])->name('konten-company-2');
Route::get('konten-company-3', [CompanyController::class,'kontencompany3'])->name('konten-company-3');

Route::get('konten-jobseeker-1', [CompanyController::class,'kontenjobseeker1'])->name('konten-jobseeker-1');
Route::get('konten-jobseeker-2', [CompanyController::class,'kontenjobseeker2'])->name('konten-jobseeker-2');
Route::get('konten-jobseeker-3', [CompanyController::class,'kontenjobseeker3'])->name('konten-jobseeker-3');

Route::get('/job/list',                         [JobController::class,'list'])->name('job.list'); 
Route::get('/job/view',                         [JobController::class,'view'])->name('job.view'); 
Route::post('/job/add',                         [JobController::class,'add'])->name('job.add'); 
Route::get('/job/{id}/edit',                     [JobController::class,'edit'])->name('job.edit');
Route::post('/job/update',                       [JobController::class,'update'])->name('job.update');
Route::get('/job/{id}/delete',                   [JobController::class,'delete'])->name('job.delete');
Route::get('/job/{id}/apply',         [JobController::class,'myApplication'])->name('job.get');


Route::post('/jobapplication/search',             [JobApplicationController::class,'search'])->name('jobapplication.search');
Route::get('/jobapplication/detail',             [JobApplicationController::class,'applicationDetail'])->name('jobapplication.detail');
Route::get('/jobapplication/{id}/apply',         [JobApplicationController::class,'myApplication'])->name('jobapplication.apply');
Route::get('/jobapplication/{id}/send',          [JobApplicationController::class,'applyApplication'])->name('jobapplication.send');
Route::get('/jobapplication/list',               [JobApplicationController::class,'myApplicationList'])->name('jobapplication.list');
Route::get('/jobapplication/{id}/companylist',   [JobApplicationController::class,'companyApplicationList'])->name('jobapplication.companylist');
Route::get('/jobapplication/{id}/bookmarked',    [JobApplicationController::class,'bookmarkApplication'])->name('jobapplication.bookmarked');
Route::get('/jobapplication/{id}/deletebookmark',[JobApplicationController::class,'deleteBookmark'])->name('jobapplication.deletebookmark');
Route::get('/jobapplication/{id}/viewProfile',[JobApplicationController::class,'viewProfile'])->name('jobapplication.viewProfile');

Route::get('/jobapplication/bookmarked/list',    [JobApplicationController::class,'bookmarkApplicationList'])->name('jobapplication.bookmarklist');
Route::get('/jobapplication/{id}/{status}/{jobseeker_id}/company/confirm',    [JobApplicationController::class,'confirm'])->name('jobapplication.confirm');

Route::get('search', [SearchController::class,'index'])->name('search.index');
Route::post('search/users', [SearchController::class,'search'])->name('search.post');

