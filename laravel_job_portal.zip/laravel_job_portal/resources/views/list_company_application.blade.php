<div class="container">
    <header class="lh-1 py-3">
        <h2>Daftar Pelamar</h2>
    </header>
</div>
<main class="container flex-grow-1">
    <article class="blog-post ">
        <table id="list_company_application" class="table ">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Pelamar</th>
                    <th>Profil</th>
                    <th>CV</th>
                    <th>Konfirmasi</th>
                </tr>
            </thead>
            <tbody>
                @if($listJobAplication)
                @foreach($listJobAplication as $jobApp => $list)
                <tr>
                    <td>1</td>
                    <td>{{$list->js_name}}</td>
                    <td>{{$list->js_id}}</td>
                    <td><a href="{{asset('uploads')}}/{{$list->file}}" class="form-control">Download</a></td>
                    <td>
                        @if($list->status =='menunggu')
                        <a href="{{route('jobapplication.confirm',['id'=>$list->job_id,'status'=>'ditolak','jobseeker_id'=>$list->jobseeker_id])}}" class="btn btn-block "><i class="fas fa-times"></i></a>
                        <a href="{{route('jobapplication.confirm',['id'=>$list->job_id,'status'=>'diterima','jobseeker_id'=>$list->jobseeker_id])}}" class="btn btn-block"><i class="fas fa-check"></i></a>
                        @else
                        {{$list->status}}
                        @endif
                    </td>
                </tr>
                @endforeach
                @endif
            </tbody>
        </table>
    </article>
</main>
<script>
$(function() {
    $('#list_company_application').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });

});

</script>
