<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <h2>Seputar Kerja</h2>
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <div class="album py-5">
        <div class="container">
            <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                @if($company)
                @foreach($company as $comp => $list)
                <div class="col">
                    <div class="card shadow-sm">
                        <img src="{{asset('uploads')}}/{{$list->image}}" alt="" style="width: 50%;">
                        <div class="card-body">
                            <h3>{{$list->description}}</h3>
                            <p class="card-text">{{$list->address}}</p>

                            <div class="d-flex justify-content-between align-items-center">
                                <div class="btn-group">
                                    <a href="" class="btn btn-sm btn-outline-secondary">Selengkapnya</a>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
                @endif
                
            </div>
        </div>
    </div>
</main>
