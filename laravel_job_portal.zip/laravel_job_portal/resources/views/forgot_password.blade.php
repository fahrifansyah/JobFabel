<div class="container">
    <div class="row flex-nowrap justify-content-between align-items-center">           
        <div class="col-9 text-center">
           <div class="input-group">
                <span class="input-group-text" id="basic-addon1">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search" viewBox="0 0 16 16">
                        <path d="M11.742 10.344a6.5 6.5 0 1 0-1.397 1.398h-.001c.03.04.062.078.098.115l3.85 3.85a1 1 0 0 0 1.415-1.414l-3.85-3.85a1.007 1.007 0 0 0-.115-.1zM12 6.5a5.5 5.5 0 1 1-11 0 5.5 5.5 0 0 1 11 0z"></path>
                    </svg>
                </span>
                <input type="text" class="form-control" placeholder="" aria-label="Input group example" aria-describedby="basic-addon1">
            </div>
        </div>
        <div class="col-md-3 mx-auto my-5 d-flex justify-content-end align-items-center">                
            <a class="btn btn-sm btn-outline-secondary btn-block" href="#">Search</a>
        </div>
    </div>  
</div>
<main class="container flex-grow-1">
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 1</h5>
            <h5 class="fw-normal text-muted mb-3">(Rekomendasi Pekerjaan)</h5>
        </div>
    </div>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 2</h5>
            <h5 class="fw-normal text-muted mb-3">(FAQ Website)</h5>
        </div>
    </div>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 3</h5>
            <h5 class="fw-normal text-muted mb-3">(Tentang Website)</h5>
        </div>
    </div>
</main>

<button id="new_password_button" type="button"data-bs-toggle="modal" data-bs-target="#new_password">Submit</button>
<!-- Modal Password Baru-->
<div class="modal fade" id="new_password" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <form class="modal-dialog" method="post" action="{{route('registered')}}">
        @csrf
        <div class="modal-content">
             <div class="modal-header d-flex justify-content-center flex-column align-items-center">
                <h5 class="text-start align-self-start" id="staticBackdropLabel">Tahap 2</h5>
                @if($cekUser)
                <h2 class="text-center fw-bold" id="staticBackdropLabel">Setel Ulang Password</h2>    
                @else
                <h5 class="text-center fw-bold" id="staticBackdropLabel">Data Tidak Ditemukan</h5>          
                @endif        
            </div>

            <div class="modal-body">
                @if($cekUser)
                <input type="hidden" name="email" value="{{$cekUser->email}}">
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="password" id="exampleFormControlInput1" placeholder="Password Baru">
                </div>         
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="confirm_password" id="exampleFormControlInput1" placeholder="Konfirmasi Passowrd Baru">
                </div>        
                <div class="mb-3">                   
                    <button type="submit" class="btn btn-secondary form-control">Submit</button>
                </div>
                @else               
                <div class="mb-3">                   
                    <a  href="{{route('home.index')}}" class="btn btn-secondary form-control">Back</a>
                </div>
                 @endif
                
                
            </div>      
        </div>
    </form>
</div>

<script type="text/javascript">
        $(document).ready(function() {
              $('#new_password_button').trigger('click');    
        });

</script>
