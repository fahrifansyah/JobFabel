<!doctype html>
<html lang="en" data-bs-theme="auto">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <meta name="generator" content="Hugo 0.112.5">
    <title>Product example · Bootstrap v5.3</title>
    <link href="{{asset('assets/dist/css/bootstrap.min.css')}}" rel="stylesheet">
    
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
</head>

<body>
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/dist/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
     <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
    <div class="d-flex flex-column min-vh-100">
        <nav class="navbar navbar-expand-md bg-light border-bottom" data-bs-theme="light">
            <div class="container">
                <a class="navbar-brand d-md-none" href="#">
                    <svg class="bi" width="24" height="24">
                        <use xlink:href="#aperture" /></svg>
                    Aperture
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvas" aria-controls="offcanvas" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvas" aria-labelledby="offcanvasLabel">
                    <div class="offcanvas-header">
                        <h5 class="offcanvas-title" id="offcanvasLabel">Aperture</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                    </div>
                    <div class="offcanvas-body">
                        <ul class="navbar-nav flex-grow-1 justify-content-between">
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <svg class="bi" width="24" height="24">
                                        <use xlink:href="#aperture" />
                                    </svg>Logo
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="j_detail" href="{{route('jobapplication.detail')}}">Detail Pekerjaan</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="c_about" href="{{route('company.about')}}">Seputar Kerja</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Bookmark</a>
                            </li>
                            <?php if($is_user == 2){ ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    {{$username}}
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="{{route('company.index')}}">Profil</a></li>
                                    <li><a class="dropdown-item" href="{{url('logout')}}">Logout</a></li>
                                </ul>
                            </li>
                            <?php } 
                                elseif($is_user == 1){
                             ?>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                    {{$username}}
                                </a>
                                <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <li><a class="dropdown-item" href="{{route('jobseeker.index')}}">Profil</a></li>
                                    <li><a class="dropdown-item" href="{{url('logout')}}">Logout</a></li>
                                </ul>
                            </li>
                            <?php }else{ ?>
                            <li>
                                <button class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#login"> Login / Regist
                                </button>
                            </li>
                            <?php }?>
                        </ul>
                    </div>
                </div>
            </div>
        </nav>
        <script type="text/javascript">
        $(document).ready(function() {
            let user_id = "{{$is_user}}";
            $("#ja_list").on("click", function(e) {               
                if (user_id == "1") {
                    window.location.href = $(this).attr('href');
                } else {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Dilarang',
                        text: 'Ini Adalah Fitur User',
                        showConfirmButton: false,
                        showCancelButton: true,
                        allowOutsideClick: false,
                    });
                }
            });
            $("#j_detail").on("click", function(e) {
                if (user_id == "1") {
                    window.location.href = $(this).attr('href');
                } else {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Dilarang',
                        text: 'Ini Adalah Fitur User',
                        showConfirmButton: false,
                        showCancelButton: true,
                        allowOutsideClick: false,
                    });
                }

            });
            $("#c_about").on("click", function(e) {
                if (user_id == "1") {
                    window.location.href = $(this).attr('href');
                } else {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Dilarang',
                        text: 'Ini Adalah Fitur User',
                        showConfirmButton: false,
                        showCancelButton: true,
                        allowOutsideClick: false,
                    });
                }

            });
            $("#js_bookmark").on("click", function(e) {
                if (user_id == "1") {
                    window.location.href = $(this).attr('href');
                } else {
                    e.preventDefault();
                    Swal.fire({
                        title: 'Dilarang',
                        text: 'Ini Adalah Fitur User',
                        showConfirmButton: false,
                        showCancelButton: true,
                        allowOutsideClick: false,
                    });
                }

            });
            $("#j_list").on("click", function(e) {
               
                e.preventDefault();
                if (user_id == "2") {

                    window.location.href = $(this).attr('href');
                } else {
                    Swal.fire({
                        title: 'Dilarang',
                        text: 'Ini Adalah Fitur Company',
                        showConfirmButton: false,
                        showCancelButton: true,
                        allowOutsideClick: false,
                    });
                }

            });
        });

        </script>
