
    <!-- hero selection start -->
    <section class="hero" id="home">
        <main class="content">
            <h1>Kami Menyediakan <span>Lowongan Pekerjaan! </span></h1>
            <p>Mari ekspresikan dan warnai dunia</p>
            <a href="#" class="cta">Cari Sekarang!</a>
        </main>
        <!-- login form -->
        <div class="wrapper">
            <span class="icon-close"><i data-feather="x"></i></span>
            <div class="form-box login">
                <h2>Login</h2>
                <form action="#">
                    <div class="input-box">
                        <span class="icon"><i data-feather="mail"></i></span>
                        <input type="email" required />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="key"></i></span>
                        <input type="password" required />
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox" /> Remember me</label>
                        <a href="#">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn">Login</button>
                    <div class="login-register">
                        <p>Don't have account? <a href="#" class="register-link">Register</a></p>
                    </div>
                </form>
            </div>
            <!-- register form start -->
            <div class="form-box register">
                <h2>Register</h2>
                <form action="#">
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" required />
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="mail"></i></span>
                        <input type="email" required />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="key"></i></span>
                        <input type="password" required />
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox" />I agree to the terms & conditions</label>
                    </div>
                    <button type="submit" class="btn">Register</button>
                    <div class="login-register">
                        <p>Already have an account? <a href="#" class="login-link">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
        <!-- register form end -->
        </div>
        <!-- loginform end -->
    </section>
    <!-- hero selection end -->
    <!-- About Section Start -->
    <section id="about" class="about">
        <h2>Tentang <span>Kami</span></h2>
        <div class="row">
            <div class="about-img">
                <img src="img/tentang kami.jpg" alt="Tentang Kami" />
            </div>
            <div class="content">
                <h3>Selamat datang di Job Portal untuk Orang dengan Disabilitas!</h3>
                <p>Kami adalah platform online yang didedikasikan untuk membantu orang dengan disabilitas mencari pekerjaan yang cocok dengan keterampilan, keinginan, dan kebutuhan mereka.</p>
                <p>
                    Kami menyadari bahwa orang dengan disabilitas seringkali menghadapi tantangan unik dalam mencari pekerjaan. Oleh karena itu, misi kami adalah untuk memudahkan proses pencarian pekerjaan bagi orang dengan disabilitas dengan
                    menyediakan akses ke pekerjaan yang terbuka, akomodasi yang diperlukan selama proses wawancara dan di tempat kerja, dan sumber daya yang berguna untuk membantu mereka sukses dalam karir mereka.
                </p>
            </div>
        </div>
    </section>
    <!-- About Section End -->
    <!-- menuselection Start -->
    <section id="listcompany" class="listcompany">
        <h2>Company <span>List</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
    </section>
    <!-- menuselection end -->
    <!-- contact section start -->
    <section id="contact" class="contact">
        <h2>Contact <span>Us</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
        <form action=""></form>
    </section>
    <!-- contact section end -->
    