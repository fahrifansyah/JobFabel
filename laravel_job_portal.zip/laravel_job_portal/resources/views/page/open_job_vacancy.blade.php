 <!-- Buka Lowongan Kerja start -->
    <main>
        <h1>Buka Lowongan Kerja</h1>
        <div class="button-buat-lowongan">
            <a class="card-btn btn btn-primary p-2" href="BuatLowonganKerja.html" role="button">Buat Lowongan Pekerjaan</a>
        </div>
        <section class="buka-lowongan-kerja">
            <table class="table table-hover">
                <thead class="table-awal bg-primary">
                  <tr>
                    <th scope="col">Nomor</th>
                    <th scope="col">Posisi Pekerjaan</th>
                    <th scope="col">Daftar Pelamar</th>
                    <th scope="col">Tanggal Dibuat</th>
                    <th scope="col"></th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody class="table-group-divider">
                  <tr>
                    <th scope="row">1</th>
                    <td>Graphic Design</td>
                    <td><a class="tombol" href="DaftarPelamar.html">Pelamar</a></td>
                    <td>15 - 05 - 2023</td>
                    <td><a class="tombol" href="EditLowonganPekerjaan.html">Edit</a></td>
                    <td>
                        <button type="button" class="btn tombol" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Hapus
                        </button>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Hapus Lowongan Pekerjaan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Lowongan pekerjaan akan dihapus secara permanen ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                        <button type="button" class="btn btn-primary">Iya</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">2</th>
                    <td>Management Accounting</td>
                    <td><a class="tombol" href="DaftarPelamar.html">Pelamar</a></td>
                    <td>17 - 05 - 2023</td>
                    <td><a class="tombol" href="EditLowonganPekerjaan.html">Edit</a></td>
                    <td>
                        <button type="button" class="btn tombol" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Hapus
                        </button>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Hapus Lowongan Pekerjaan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Lowongan pekerjaan akan dihapus secara permanen ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                        <button type="button" class="btn btn-primary">Iya</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">3</th>
                    <td>Admin</td>
                    <td><a class="tombol" href="DaftarPelamar.html">Pelamar</a></td>
                    <td>18 - 05 - 2023</td>
                    <td><a class="tombol" href="EditLowonganPekerjaan.html">Edit</a></td>
                    <td>
                        <button type="button" class="btn tombol" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Hapus
                        </button>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Hapus Lowongan Pekerjaan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Lowongan pekerjaan akan dihapus secara permanen ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                        <button type="button" class="btn btn-primary">Iya</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                  </tr>
                  <tr>
                    <th scope="row">4</th>
                    <td>Content Creator</td>
                    <td><a class="tombol" href="DaftarPelamar.html">Pelamar</a></td>
                    <td>20 - 05 - 2023</td>
                    <td><a class="tombol" href="EditLowonganPekerjaan.html">Edit</a></td>
                    <td>
                        <button type="button" class="btn tombol" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                            Hapus
                        </button>
                        
                        <!-- Modal -->
                        <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h1 class="modal-title fs-5" id="staticBackdropLabel">Hapus Lowongan Pekerjaan</h1>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Lowongan pekerjaan akan dihapus secara permanen ?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tidak</button>
                                        <button type="button" class="btn btn-primary">Iya</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                  </tr>
                </tbody>
            </table>
        </section>
        <section class="tombol-page-lain d-flex justify-content-between">
            <a class="btn btn-primary" href="editprofilecompany.html">Sebelumnya</a>
            <div class="btn-group">
                <a href="#" class="btn btn-outline-primary active" aria-current="page">1</a>
                <a href="#" class="btn btn-outline-primary">2</a>
                <a href="#" class="btn btn-outline-primary">3</a>
              </div>
            <a class="btn btn-primary" href="editprofilecompany.html">Selanjutnya</a>
        </section>
    </main>
    <!-- Buka Lowongan Kerja End -->