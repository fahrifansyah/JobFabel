<main class="container flex-grow-1">
    <form method="post" action="{{route('jobseeker.update')}}" enctype="multipart/form-data">
       @csrf
        <div class="position-relative overflow-hidden p-0 text-center ">            
            <h2 class="text-start">Edit Profile User</h2>                    
        </div>        

        <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">     
            <input type="hidden" name="jobseeker_id" value="{{$jobseeker->id}}">   
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_username" value="{{$user->username}}">   
            </div>
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_email" value="{{$user->email}}">   
            </div>
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_password" placeholder="Password">   
            </div>
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_name" value="{{$jobseeker->name}}">   
            </div>
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_gender" value="{{$jobseeker->gender}}">   
            </div>
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_dob" value="{{$jobseeker->dob}}">   
            </div>
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_experience" value="{{$jobseeker->experience}}">   
            </div>
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_education" value="{{$jobseeker->education}}" placeholder="Pendidikan">   
            </div>
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_address" value="{{$jobseeker->address}}" placeholder="Alamat">   
            </div>
            <div class="mb-3">                   
                <input type="text"  class="form-control" name="jobseeker_disability" value="{{$jobseeker->disability}}">   
            </div>
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_phone" value="{{$jobseeker->phone}}">   
            </div>       
            <div class="mb-3">                    
                <input type="text"  class="form-control" name="jobseeker_description" value="{{$jobseeker->description}}" placeholder="Deskripsi Diri">   
            </div>                 
           <div class="mb-3">
                <div class="d-flex align-items-start flex-column">
                    <label for="imageUpload" class="form-label">Upload Image</label>
                    <div class="d-flex align-items-center">
                        <div id="thumbnailContainer" class="me-3">
                            <img id="thumbnail" class="img-thumbnail" src="{{asset('uploads')}}/{{$jobseeker->image}}" alt="Thumbnail">
                        </div>
                        <div>
                            <button type="button" class="btn btn-secondary" id="uploadButtonImage">Choose Image</button>
                            <input type="file" name="job_seeker_image" class="form-control visually-hidden" id="imageUpload" accept="image/*">
                        </div>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <label for="fileUpload" class="form-label">Upload File</label>
                <div class="input-group">
                    <input type="text"  class="form-control" id="fileNameContainer" readonly>
                    <button type="button" class="btn btn-secondary" id="uploadButtonFile">Browse</button>
                </div>
                <input type="file" name="job_seeker_file" class="form-control visually-hidden" id="fileUpload">
            </div>
            <div class="row">       
                <div class="col-md-6">
                    <a href="{{route('jobseeker.index')}}" class="btn btn-secondary form-control">Batal</a>
                </div>  
                <div class="col-md-6">
                    <button type="submit" class="btn btn-secondary form-control">Simpan</button>
                </div>   
            </div>
        </div>
    
   </form>
</main>

<script>   
    const uploadButtonImage = document.getElementById('uploadButtonImage');
    const imageUpload = document.getElementById('imageUpload');
    const thumbnail = document.getElementById('thumbnail');

    uploadButtonImage.addEventListener('click', function() {
        imageUpload.click();
    });

    imageUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.addEventListener('load', function() {
                thumbnail.src = reader.result;
            });

            reader.readAsDataURL(file);
        } else {
            thumbnail.src = '#';
        }
    });

    const uploadButtonFile = document.getElementById('uploadButtonFile');
    const fileUpload = document.getElementById('fileUpload');
    const fileNameContainer = document.getElementById('fileNameContainer');

    uploadButtonFile.addEventListener('click', function() {
        fileUpload.click();
    });

    fileUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            fileNameContainer.value = file.name;
        } else {
            fileNameContainer.value = '';
        }
    });


</script>