<main class="container flex-grow-1">
    <div class="position-relative overflow-hidden p-0 text-center ">
      <div class="row">
            <div class="col-md-9 pt-5">               
                <h2 class="text-start">Profil User</h2>                
            </div>
            <div class="col-md-3 pt-5">
                <div class="input-group">
                <a class="form-control" href="{{route('jobseeker.edit')}}">Edit Profil</a>
                </div>
            </div>
        </div>          
    </div>        
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="row">
            <div class="col-3 text-start px-0">                              
                <img src="{{asset('uploads')}}/{{$jobseeker->image}}" alt="">               
            </div>            
            <div class="col-9 ">
                <h1>{{$jobseeker->name}}</h1>               
                <h3> {{$jobseeker->description}}</h3>
            </div>
        </div>
    </div>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 2</h5>
            <h5 class="fw-normal text-muted mb-3">(FAQ Website)</h5>
           
        </div>
    </div>
   
</main>