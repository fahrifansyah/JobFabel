<main class="container flex-grow-1">    
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 1</h5>
            <h5 class="fw-normal text-muted mb-3">(Rekomendasi Pekerjaan)</h5>
            
        </div>
    </div>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 2</h5>
            <h5 class="fw-normal text-muted mb-3">(FAQ Website)</h5>
           
        </div>
    </div>
    <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">
        <div class="col-md-6 p-lg-5 mx-auto my-5">
            <h5 class="fw-normal text-muted mb-3">Section 3</h5>
            <h5 class="fw-normal text-muted mb-3">(Tentang Website)</h5>
            
        </div>
    </div>
</main>


<!-- Modal Login -->
<div class="modal fade" id="login" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <form class="modal-dialog" method="post" action="{{route('login')}}">
    @csrf
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5 text-center" id="staticBackdropLabel">Login</h1>       
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <!-- <label for="exampleFormControlInput1" class="form-label">Username</label> -->
                    <input type="text" class="form-control" name="login_username"  placeholder="Username">
                </div>
                <div class="mb-3">
                    <!--  <label for="exampleFormControlTextarea1" class="form-label">Password</label> -->
                    <input type="text" class="form-control" name="login_password" placeholder="Password">
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label"><a href="#" data-bs-toggle="modal" data-bs-target="#forgot_password">Lupa Password</a></label>
                    <button type="submit" class="btn btn-secondary form-control">Login</button>
                </div>
                <div class="mb-3">
                    <label for="exampleFormControlTextarea1" class="form-label">Tidak Punya Akun ? <a href="#" data-bs-toggle="modal" data-bs-target="#register_1">Register disini</a> </label>                  
                </div>
            </div>      
        </div>
    </form>
</div>

<!-- Modal Lupa Password-->
<div class="modal fade" id="forgot_password" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <form class="modal-dialog" method="post" action="{{route('validate')}}">
        @csrf
        <div class="modal-content">
             <div class="modal-header d-flex justify-content-center flex-column align-items-center">
                <h5 class="text-start align-self-start" id="staticBackdropLabel">Tahap 1</h5>
                <h2 class="text-center fw-bold" id="staticBackdropLabel">Lupa Pasword</h2>
                
            </div>
            <div class="modal-body">
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="email" placeholder="Email">
                </div>          
                <div class="mb-3">                   
                    <button type="submit" class="btn btn-secondary form-control">Submit</button>
                </div>
                
            </div>      
        </div>
    </form>
</div>





<form  method="post" action="{{route('register.jobseeker')}}" enctype="multipart/form-data">
 @csrf
    <!-- Modal Register 1-->
    <div class="modal fade" id="register_1" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">   
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center flex-column align-items-center">
                    <h5 class="text-start align-self-start" id="staticBackdropLabel">Tahap 1</h5>
                    <h2 class="text-center fw-bold" id="staticBackdropLabel">Register</h2>
                    <div class="row">
                        <div class="col-md-6">
                            <button type="button" class="btn btn-light btn-block" data-bs-toggle="modal" data-bs-target="#register_1">User</button>
                        </div>
                        <div class="col-md-6">
                            <button type="button" class="btn btn-secondary btn-block" data-bs-toggle="modal" data-bs-target="#CompanyRegistration">Company</button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                    <div class="mb-3">                   
                        <input type="text" class="form-control" name="job_seeker_name" placeholder="Nama">
                    </div>
                    <div class="mb-3">                    
                        <input type="text" class="form-control" name="job_seeker_dob" placeholder="Tanggal Lahir">
                    </div>
                    <div class="mb-3">                   
                        <input type="text" class="form-control" name="job_seeker_gender" placeholder="Jenis Kelamin">
                    </div>
                    <div class="mb-3">                    
                        <input type="text" class="form-control" name="job_seeker_username" placeholder="Username">
                    </div>
                    <div class="mb-3">                   
                        <input type="text" class="form-control" name="job_seeker_email" placeholder="Email">
                    </div>
                    <div class="mb-3">                    
                        <input type="text" class="form-control" name="job_seeker_phone" placeholder="No.Telp">
                    </div>
                    <div class="mb-3">                   
                        <input type="text" class="form-control" name="job_seeker_disability" placeholder="Jenis Disabilitas">
                    </div>
                    <div class="mb-3">                    
                        <input type="text" class="form-control" name="job_seeker_experience" placeholder="Kemampuan">
                    </div>
                    <div class="mb-3">                   
                        <input type="text" class="form-control" name="job_seeker_password" placeholder="Password">
                    </div>
                    <div class="mb-3">                    
                        <input type="text" class="form-control" name="job_seeker_confirm_password" placeholder="Konfirmasi Password">
                    </div>
                    <div class="mb-3">                   
                        <button type="button" class="btn btn-secondary form-control" data-bs-toggle="modal" data-bs-target="#register_2">Selanjutnya</button>
                    </div>
                    
                </div>      
            </div>
        </div>
    </div>

    <!-- Modal Register 2 -->
    <div class="modal fade" id="register_2" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-center flex-column align-items-center">
                    <h5 class="text-start align-self-start" id="staticBackdropLabel">Tahap 2</h5>
                    <h2 class="text-center fw-bold" id="staticBackdropLabel">Register</h2>
                    <div class="row">
                        <div class="col-md-6">
                            <button type="button" class="btn btn-light btn-block" data-bs-toggle="modal" data-bs-target="#register_2">User</button>
                        </div>
                        <div class="col-md-6">
                           <button type="button" class="btn btn-secondary btn-block" data-bs-toggle="modal" data-bs-target="#CompanyRegistration">Company</button>
                        </div>
                    </div>
                </div>
                <div class="modal-body">
                  
                    <div class="mb-3">
                        <div class="d-flex align-items-start flex-column">
                            <label for="imageUpload" class="form-label">Upload Image</label>
                            <div class="d-flex align-items-center">
                                <div id="thumbnailContainer" class="me-3">
                                    <img id="thumbnail" class="img-thumbnail" src="#" alt="Thumbnail">
                                </div>
                                <div>
                                    <button type="button" class="btn btn-secondary" id="uploadButtonImage">Choose Image</button>
                                    <input type="file" name="job_seeker_image" class="form-control visually-hidden" id="imageUpload" accept="image/*">
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label for="fileUpload" class="form-label">Upload File</label>
                        <div class="input-group">
                            <input type="text" class="form-control" id="fileNameContainer" readonly>
                            <button type="button" class="btn btn-secondary" id="uploadButtonFile">Browse</button>
                        </div>
                        <input type="file" name="job_seeker_file" class="form-control visually-hidden" id="fileUpload">
                    </div>
                    
                    <div class="mb-3">
                        <button type="submit" class="btn btn-secondary form-control">Register</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<!-- Modal Register Company-->
<div class="modal fade" id="CompanyRegistration" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <form class="modal-dialog" method="post" action="{{route('register.company')}}" enctype="multipart/form-data">
    @csrf
        <div class="modal-content">
            <div class="modal-header d-flex justify-content-center flex-column align-items-center">                
                <h2 class="text-center fw-bold" id="staticBackdropLabel">Register</h2>
                <div class="row">
                    <div class="col-md-6">
                        <button type="button" class="btn btn-secondary btn-block" data-bs-toggle="modal" data-bs-target="#register_1">User</button>
                    </div>
                    <div class="col-md-6">
                       <button type="button" class="btn btn-light btn-block" data-bs-toggle="modal" data-bs-target="#CompanyRegistration">Company</button>
                    </div>
                </div>
            </div>
            <div class="modal-body">
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_name" placeholder="Nama Company">
                </div>
                <div class="mb-3">                    
                    <input type="text" class="form-control" name="company_username" placeholder="Username">
                </div>
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_email" placeholder="Email">
                </div>
                <div class="mb-3">                    
                    <input type="text" class="form-control" name="company_description" placeholder="Deskripsi">
                </div>
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_address" placeholder="Alamat">
                </div>
                <div class="mb-3">                    
                    <input type="text" class="form-control" name="company_phone" placeholder="No.Telp">
                </div>
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_website" placeholder="Website">
                </div>                
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_category" placeholder="Kategori">
                </div>
                <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_language" placeholder="Bahasa">
                </div>
                 <div class="mb-3">                   
                    <input type="text" class="form-control" name="company_password" placeholder="Password">
                </div>
                <div class="mb-3">                    
                    <input type="text" class="form-control" name="company_confirm_password" placeholder="Konfirmasi Password">
                </div>
                  <div class="mb-3">
                        <div class="d-flex align-items-start flex-column">
                            <label for="companyImageUpload" class="form-label">Upload Image</label>
                            <div class="d-flex align-items-center">
                                <div id="companyThumbnailContainer" class="me-3">
                                    <img id="companyThumbnail" class="img-thumbnail" src="#" alt="Thumbnail">
                                </div>
                                <div>
                                    <button type="button" class="btn btn-secondary" id="companyUploadButton">Choose Image</button>
                                    <input type="file" name="company_image" class="form-control visually-hidden" id="companyImageUpload" accept="image/*">
                                </div>
                            </div>
                        </div>
                    </div>
                <div class="mb-3">                   
                    <button type="submit" class="btn btn-secondary form-control">Register</button>
                </div>
                
            </div>      
        </div>
    </form>
</div>
<script>
    const uploadButtonImage = document.getElementById('uploadButtonImage');
    const imageUpload = document.getElementById('imageUpload');
    const thumbnail = document.getElementById('thumbnail');

    uploadButtonImage.addEventListener('click', function() {
        imageUpload.click();
    });

    imageUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.addEventListener('load', function() {
                thumbnail.src = reader.result;
            });

            reader.readAsDataURL(file);
        } else {
            thumbnail.src = '#';
        }
    });

    const uploadButtonFile = document.getElementById('uploadButtonFile');
    const fileUpload = document.getElementById('fileUpload');
    const fileNameContainer = document.getElementById('fileNameContainer');

    uploadButtonFile.addEventListener('click', function() {
        fileUpload.click();
    });

    fileUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            fileNameContainer.value = file.name;
        } else {
            fileNameContainer.value = '';
        }
    });

    const companyUploadButton = document.getElementById('companyUploadButton');
    const companyImageUpload = document.getElementById('companyImageUpload');
    const companyThumbnail = document.getElementById('companyThumbnail');

    companyUploadButton.addEventListener('click', function() {
        companyImageUpload.click();
    });

    companyImageUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.addEventListener('load', function() {
                companyThumbnail.src = reader.result;
            });

            reader.readAsDataURL(file);
        } else {
            companyThumbnail.src = '#';
        }
    });
</script>



