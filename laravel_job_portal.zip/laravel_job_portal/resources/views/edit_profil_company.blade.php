<main class="container flex-grow-1">
    <form method="post" action="{{route('company.update')}}" enctype="multipart/form-data">
       @csrf
        <div class="position-relative overflow-hidden p-0 text-center ">            
            <h2 class="text-start">Edit Profile Company</h2>                    
        </div>        
        <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">     
            <input type="hidden" name="company_id" value="{{$company->id}}">   
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_username" value="{{$user->username}}">   
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="company_email" value="{{$user->email}}">   
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_password" placeholder="Password">   
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_name" value="{{$company->name}}">   
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="company_description" value="{{$company->description}}">   
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_address" value="{{$company->address}}">   
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="company_phone" value="{{$company->phone}}">   
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_website" value="{{$company->website}}">   
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="company_category" value="{{$company->category}}">   
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="company_language" value="{{$company->language}}">   
            </div>                 
            <div class="mb-3">
                <div class="d-flex align-items-start flex-column">
                    <label for="companyImageUpload" class="form-label">Upload Image</label>
                    <div class="d-flex align-items-center">
                        <div id="companyThumbnailContainer" class="me-3">
                            <img id="companyThumbnail" class="img-thumbnail" src="{{asset('uploads')}}/{{$company->image}}" alt="Thumbnail">
                        </div>
                        <div>
                            <button type="button" class="btn btn-secondary" id="companyUploadButton">Choose Image</button>
                            <input type="file" name="company_image" class="form-control visually-hidden" id="companyImageUpload" accept="image/*">
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">       
                <div class="col-md-6">
                    <a href="{{route('company.index')}}" class="btn btn-secondary form-control">Batal</a>
                </div>  
                <div class="col-md-6">
                    <button type="submit" class="btn btn-secondary form-control">Simpan</button>
                </div>   
            </div>
        </div>
    
   </form>
</main>

<script>   
    const companyUploadButton = document.getElementById('companyUploadButton');
    const companyImageUpload = document.getElementById('companyImageUpload');
    const companyThumbnail = document.getElementById('companyThumbnail');

    companyUploadButton.addEventListener('click', function() {
        companyImageUpload.click();
    });

    companyImageUpload.addEventListener('change', function(event) {
        const file = event.target.files[0];

        if (file) {
            const reader = new FileReader();

            reader.addEventListener('load', function() {
                companyThumbnail.src = reader.result;
            });

            reader.readAsDataURL(file);
        } else {
            companyThumbnail.src = '#';
        }
    });
</script>