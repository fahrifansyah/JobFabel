<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <h2>Detail Pekerjaan</h2>
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <div class="row mb-2">
        <table id="job_detail" class="table">
            <thead>
                <tr>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                <th scope="col"></th>
                </tr>
                </thead>
            <tbody>
                @if($listJob)
                @foreach($listJob as $list => $job)
                <tr>
                    <th>
                        <img src="{{asset('uploads')}}/{{$job->image}}" alt="" style="width: 50%;">
                    </th>
                    <th>
                        <h3 class="mb-0">{{$job->name}}</h3>
                        <div class="mb-1 text-body-secondary">{{$job->c_name}}</div>
                        <p class="card-text mb-auto">{{$job->address}}</p>
                    </th>
                    <th>
                        <a href="{{route('jobapplication.apply',['id'=>$job->id])}}" class="btn btn-secondary btn-block">
                            Selengkapnya
                        </a>
                    </th>
                    <th>
                        <a href="{{route('jobapplication.bookmarked',['id'=>$job->id])}}" id="bookmark" class="btn btn-secondary btn-block pt-0"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bookmark">
                                <path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path>
                            </svg></a>
                    </th>
                </tr>
                <!--  <div class="col-md-12 ">
                    <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative bg-body-tertiary">               
                        <div class="col-3 d-none d-lg-block">
                            <img src="{{asset('uploads')}}/{{$job->image}}" alt="" style="width: 50%;">
                        </div> 
                        <div class="col-6 p-4 d-flex flex-column position-static">
                            <h3 class="mb-0">{{$job->name}}</h3>
                            <div class="mb-1 text-body-secondary">{{$job->c_name}}</div>
                            <p class="card-text mb-auto">{{$job->address}}</p>                    
                        </div>  
                        <div class="col-2 p-4 d-flex flex-column position-static">
                            <a href="{{route('jobapplication.apply',['id'=>$job->id])}}" class="btn btn-secondary btn-block">
                               Selengkapnya                        
                            </a>                     
                        </div>                  
                        <div class="col-1 p-4 d-flex flex-column position-static">                    
                            <a href="{{route('jobapplication.bookmarked',['id'=>$job->id])}}" id="bookmark" class="btn btn-secondary btn-block"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-bookmark"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg></a>
                        </div>      
                    </div>
                </div> -->
                @endforeach
                @endif
            </tbody>
        </table>
    </div>
</main>
<script type="text/javascript">
$(document).ready(function() {

    $('#job_detail').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });
});

</script>
