<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
     <link rel="stylesheet" href="{{asset('assets/jobfable/style.css')}}" />
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <!-- Feather iconsa -->
    <script src="https://unpkg.com/feather-icons"></script>
    <title>Welcome</title>
</head>

<body>
    <!-- navbar start -->
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
    <nav class="navbar">
        <a href="#" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
            <a href="#home">Home</a>
            <a href="#about">About</a>
            <a href="#listcompany">List Company</a>
            <a href="#contact">Contact</a>
            <button class="btnLogin-popup">Login</button>
        </div>
        <div class="navbar-extra">
            <a href="#" id="search"><i data-feather="search"></i></a>
            <a href="#" id="bookmark"><i data-feather="bookmark"></i></a>
            <a href="#" id="list"><i data-feather="menu"></i></a>
        </div>
    </nav>
    <!-- navbar end -->
    <!-- hero selection start -->
    <section class="hero" id="home">
        <main class="content">
            <h1>Kami Menyediakan <span>Lowongan Pekerjaan! </span></h1>
            <p>Mari ekspresikan dan warnai dunia</p>
            <a href="#" class="cta">Cari Sekarang!</a>
        </main>
        <!-- login form -->
        <div class="wrapper">
            <span class="icon-close"><i data-feather="x"></i></span>
            <div class="form-box login">
                <h2>Login</h2>
                <form action="#">
                    <div class="input-box">
                        <span class="icon"><i data-feather="mail"></i></span>
                        <input type="email" required />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="key"></i></span>
                        <input type="password" required />
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox" /> Remember me</label>
                        <a href="#">Forgot Password?</a>
                    </div>
                    <button type="submit" class="btn">Login</button>
                    <div class="login-register">
                        <p>Don't have account? <a href="#" class="register-link">Register</a></p>
                    </div>
                </form>
            </div>
            <!-- register form start -->
            <div class="form-box register">
                <h2>Register</h2>
                <form action="#">
                    <div class="input-box">
                        <span class="icon"><i data-feather="user"></i></span>
                        <input type="text" required />
                        <label>Username</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="mail"></i></span>
                        <input type="email" required />
                        <label>Email</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="key"></i></span>
                        <input type="password" required />
                        <label>Password</label>
                    </div>
                    <div class="remember-forgot">
                        <label><input type="checkbox" />I agree to the terms & conditions</label>
                    </div>
                    <button type="submit" class="btn">Register</button>
                    <div class="login-register">
                        <p>Already have an account? <a href="#" class="login-link">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
        <!-- register form end -->
        </div>
        <!-- loginform end -->
    </section>
    <!-- hero selection end -->
    <!-- About Section Start -->
    <section id="about" class="about">
        <h2>Tentang <span>Kami</span></h2>
        <div class="row">
            <div class="about-img">
                <img src="img/tentang kami.jpg" alt="Tentang Kami" />
            </div>
            <div class="content">
                <h3>Selamat datang di Job Portal untuk Orang dengan Disabilitas!</h3>
                <p>Kami adalah platform online yang didedikasikan untuk membantu orang dengan disabilitas mencari pekerjaan yang cocok dengan keterampilan, keinginan, dan kebutuhan mereka.</p>
                <p>
                    Kami menyadari bahwa orang dengan disabilitas seringkali menghadapi tantangan unik dalam mencari pekerjaan. Oleh karena itu, misi kami adalah untuk memudahkan proses pencarian pekerjaan bagi orang dengan disabilitas dengan
                    menyediakan akses ke pekerjaan yang terbuka, akomodasi yang diperlukan selama proses wawancara dan di tempat kerja, dan sumber daya yang berguna untuk membantu mereka sukses dalam karir mereka.
                </p>
            </div>
        </div>
    </section>
    <!-- About Section End -->
    <!-- menuselection Start -->
    <section id="listcompany" class="listcompany">
        <h2>Company <span>List</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
    </section>
    <!-- menuselection end -->
    <!-- contact section start -->
    <section id="contact" class="contact">
        <h2>Contact <span>Us</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
        <form action=""></form>
    </section>
    <!-- contact section end -->
    <!-- footer start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer end -->
    <!-- my javascript -->
    <script src="script.js"></script>
    <!-- Feather Icons -->
    <script>
    feather.replace();

    </script>
</body>

</html>
