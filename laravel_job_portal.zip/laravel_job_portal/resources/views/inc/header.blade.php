<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/jobfable/company/style.css')}}" />
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
    <script src="https://unpkg.com/feather-icons"></script>
    <title>Header</title>
</head>

<body>
    <!-- navbar start -->
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)               
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
    <!-- navbar end -->
    <script type="text/javascript">
    $(document).ready(function() {
        let user_id = "{{$is_user}}";
        $("#ja_list").on("click", function(e) {
            if (user_id == "1") {
                window.location.href = $(this).attr('href');
            } else {
                e.preventDefault();
                Swal.fire({
                    title: 'Dilarang',
                    text: 'Ini Adalah Fitur User',
                    showConfirmButton: false,
                    showCancelButton: true,
                    allowOutsideClick: false,
                });
            }
        });
        $("#j_detail").on("click", function(e) {
            if (user_id == "1") {
                window.location.href = $(this).attr('href');
            } else {
                e.preventDefault();
                Swal.fire({
                    title: 'Dilarang',
                    text: 'Ini Adalah Fitur User',
                    showConfirmButton: false,
                    showCancelButton: true,
                    allowOutsideClick: false,
                });
            }

        });
        $("#c_about").on("click", function(e) {
            if (user_id == "1") {
                window.location.href = $(this).attr('href');
            } else {
                e.preventDefault();
                Swal.fire({
                    title: 'Dilarang',
                    text: 'Ini Adalah Fitur User',
                    showConfirmButton: false,
                    showCancelButton: true,
                    allowOutsideClick: false,
                });
            }

        });
        $("#js_bookmark").on("click", function(e) {
            if (user_id == "1") {
                window.location.href = $(this).attr('href');
            } else {
                e.preventDefault();
                Swal.fire({
                    title: 'Dilarang',
                    text: 'Ini Adalah Fitur User',
                    showConfirmButton: false,
                    showCancelButton: true,
                    allowOutsideClick: false,
                });
            }

        });
        $("#j_list").on("click", function(e) {

            e.preventDefault();
            if (user_id == "2") {

                window.location.href = $(this).attr('href');
            } else {
                Swal.fire({
                    title: 'Dilarang',
                    text: 'Ini Adalah Fitur Company',
                    showConfirmButton: false,
                    showCancelButton: true,
                    allowOutsideClick: false,
                });
            }

        });
    });

    </script>
