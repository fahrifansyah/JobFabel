<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <link href="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="{{ asset('assets/jobfable/user/style-joblist.css') }}" />
    <title>Job List</title>
</head>

<body>
    <script src="{{ asset('assets/plugin/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js') }}"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <div class="container">
        <!-- NAVBAR -->
        <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)               
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
        <!-- NAVBAR END -->
        <!-- HEAD START -->
        <section id="job-list" class="job-list">
            <form method="post" action="{{ route('jobapplication.search') }}" enctype="multipart/form-data">
                @csrf
                <h2><span>Daftar Pekerjaan</span></h2>
                <div class="box">
                    <input type="search" name="slugs" id="search"
                        placeholder=" klik disini untuk mencari . . ." />
                    <a href="#">
                        <button type="submit">search</button>
                    </a>
                </div>
                <div class="filter">
                    <!-- <select name="disability" id="disability">
                    <option value="">Jenis Disabilitas</option>
                    <option value="fisik">Disabilitas Fisik</option>
                    <option value="mental">Disabilitas Mental</option>
                    <option value="sensor">Disabilitas Sensorik</option>
                    <option value="intelek">Disabilitas Intelektual</option>
                </select> -->
                    <select name="category" id="job">
                        <option value="">Kategori Pekerjaan</option>
                        <option value="it">Teknologi Informasi</option>
                        <option value="design">Desain dan Media</option>
                        <option value="business">Bisnis dan Pemasaran</option>
                        <option value="hrd">Personalia dan Legal</option>
                        <option value="prod">Produksi</option>
                        <option value="finance">Keuangan</option>
                    </select>
                    <select name="city" id="city">
                        <option value="">Domisili</option>
                        <option value="jaodetabek">JaBoDeTaBek</option>
                        <option value="jawa">Pulau Jawa (diluar jabodetabek)</option>
                        <option value="sumatera">Pulau Sumatera</option>
                        <option value="kalimantan">Pulau Kalimantan</option>
                        <option value="sulawesi">Pulau Sulawesi</option>
                        <option value="bali">Pulau Bali</option>
                        <option value="papua">Pulau Papua</option>
                    </select>
                    <select name="salary" id="salary">
                        <option value="">Gaji</option>
                        <option value="4.500.000"> &le;4.500.000</option>
                        <option value="4.500.001-7.000.000">4.500.001 - 7.000.000</option>
                        <option value="7.000.001-10.000.000">7.000.001 - 10.000.000</option>
                        <option value="10.000.001-15.000.000">10.000.001 - 15.000.000</option>
                        <option value="15.000.001-20.000.000">15.000.001 - 20.000.000</option>
                        <option value="20.000.001">&ge;20.000.001</option>
                    </select>
                </div>
            </form>
        </section>
        <!-- HEAD END -->
        <!-- CONTENT START -->
        <article id="bookmark" class="bookmark">
            <div class="row">
                @if ($listJob)
                    @foreach ($listJob as $list => $job)
                        <div class="konten" style="width: 400px;">
                            <a href="#"><img src="{{ asset('uploads') }}/{{ $job->image }}" /></a>
                            <div class="judul">
                                <a href="#">{{ $job->name }}</a>
                            </div>
                            <p1>{{ $job->c_name }}</p1>
                            <p>{{ $job->address }}</p>
                            <p>{{ $job->salary }}</p>
                            <p>{{ $job->disability }}</p>
                            <div class="detail-button">
                                <a href="{{ route('jobapplication.apply', ['id' => $job->id]) }}">
                                    <button type="submit">Selengkapnya</button>
                                </a>
                                <a href="{{ route('jobapplication.bookmarked', ['id' => $job->id]) }}" id="bookmark"><i
                                        data-feather="bookmark"></i></a>
                            </div>
                        </div>
                    @endforeach
                @endif

            </div>
        </article>
        <!-- CONTENT END -->
        <!-- PAGINATION -->
        <section class="pagination">
            <div class="pagination">
                <a class="desc" href="#">&laquo; Sebelumnya</a>
                <a class="active" href="#">1</a>
                <a href="#">2</a>
                <a href="#">3</a>
                <a href="#">4</a>
                <a href="#">5</a>
                <a href="#">6</a>
                <a class="desc" href="#">Selanjutnya &raquo;</a>
            </div>
        </section>
        <!-- FOOTER START-->
        <footer>
            <div class="social">
              <a href="#"><i data-feather="mail"></i> </a>
            </div>
            <div class="links">
              <a href="{{ url('/') }}#home">Home</a>
              <a href="{{ url('/') }}#about">Tentang Kami</a>
            </div>
            <div class="credit">
              <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
            </div>
          </footer>
    </div>
    <!-- my javascript -->
    <script src="script.js"></script>
    <!-- Feather Icons-->
    <script>
        feather.replace();
    </script>
</body>

</html>
