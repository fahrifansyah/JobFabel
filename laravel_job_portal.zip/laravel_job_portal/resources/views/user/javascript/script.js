// toggle class active
const navbarNav = document.querySelector('.navbar-nav');
// ketika menu di click
document.querySelector('#list').onclick = () => {
  navbarNav.classList.toggle('active');
};
//klik di luar sidebar untuk menghilangkan nav
const list = document.querySelector('#list');
document.addEventListener('click', function (e) {
  if (!list.contains(e.target) && !navbarNav.contains(e.target)) {
    navbarNav.classList.remove('active');
  }
});
//transisi login-register
const wrapper = document.querySelector('.wrapper');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPopup = document.querySelector('.btnLogin-popup');
const iconClose = document.querySelector('.icon-close');
// ketika register-login di click
registerLink.addEventListener('click', () => {
  wrapper.classList.add('active');
});
loginLink.addEventListener('click', () => {
  wrapper.classList.remove('active');
});
btnPopup.addEventListener('click', () => {
  wrapper.classList.add('active-popup');
});
// ketika click closeicon
iconClose.addEventListener('click', () => {
  wrapper.classList.remove('active-popup');
});
