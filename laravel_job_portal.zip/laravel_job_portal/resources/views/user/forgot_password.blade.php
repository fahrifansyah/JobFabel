<!DOCTYPE html>
<html lang="en">

<head> 
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">    
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
    <script src="https://unpkg.com/feather-icons"></script>
     <link rel="stylesheet" href="{{asset('assets/jobfable/user/style.css')}}" />
    <title>Forgot Password</title>
</head>

<body>
    <!-- navbar start --> 
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script> 
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
      <script src="https://unpkg.com/feather-icons"></script>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
            <!-- <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a> -->
                           
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
           
        </div>
        <div class="navbar-extra">
            
        </div>
    </nav>
    <!-- hero selection start -->
    <section class="hero" id="home">
        <main class="content">
            <h1>Kami Menyediakan Lowongan Pekerjaan!</h1>
            <p>Mari ekspresikan dan warnai dunia</p>
            <a id="lupa-password" href="#lupa-password" rel="modal:open"></a>
        </main>
        <div class="wrapper">
            
             <a href="#lupa-password" rel="modal:open">test</a>
            <!-- forgot form start -->
            <div id="lupa-password" class="form-box register">
                <h2>Lupa Password</h2>
                 <form method="post" action="{{route('forgot')}}" enctype="multipart/form-data">
                @csrf
                    <input type="text" name="id" value="{{$id}}">
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input name="password" type="password" />
                        <label>Password</label>
                    </div>
                    <div class="input-box">
                        <span class="icon"><i data-feather="email"></i></span>
                        <input name="confirm_password" type="password" />
                        <label>Konfirmasi Password</label>
                    </div>
                    <button type="submit" class="btn">Kirim</button>
                </form>
            </div>
        </div>
        </div>
        <!-- loginform end -->
    </section>
    <!-- hero selection end -->
    <!-- About Section Start -->
    <section id="about" class="about">
        <h2><span>Tentang Kami</span></h2>
        <div class="row">
            <div class="about-img">
                <img src="{{asset('assets/img/tentang_kami.jpg')}}" alt="Tentang Kami" />
            </div>
            <div class="content">
                <h3>Selamat datang di Job Portal untuk Orang dengan Disabilitas!</h3>
                <p>Kami adalah platform online yang didedikasikan untuk membantu orang dengan disabilitas mencari pekerjaan yang cocok dengan keterampilan, keinginan, dan kebutuhan mereka.</p>
                <p>
                    Kami menyadari bahwa orang dengan disabilitas seringkali menghadapi tantangan unik dalam mencari pekerjaan. Oleh karena itu, misi kami adalah untuk memudahkan proses pencarian pekerjaan bagi orang dengan disabilitas dengan
                    menyediakan akses ke pekerjaan yang terbuka, akomodasi yang diperlukan selama proses wawancara dan di tempat kerja, dan sumber daya yang berguna untuk membantu mereka sukses dalam karir mereka.
                </p>
            </div>
        </div>
    </section>
    <!-- About Section End -->
    <!-- menuselection Start -->
    <section id="listcompany" class="listcompany">
        <h2>Company <span>List</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
    </section>
    <!-- menuselection end -->
    <!-- contact section start -->
    <section id="contact" class="contact">
        <h2>Contact <span>Us</span></h2>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum perspiciatis quo aperiam! Tempora nihil eius ea sapiente quas quidem doloremque dolorum in, eligendi esse explicabo, sint eum blanditiis unde praesentium.</p>
        <form action=""></form>
    </section>
    <!-- contact section end -->
    <!-- navbar end -->
    <script type="text/javascript">
        $(document).ready(function() {           
           $('#lupa-password').trigger('click');    
            
        });

    </script>
    <!-- footer start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer end -->
    <script>
    feather.replace();

    </script>
    <script>
@if($message = session('success'))
Swal.fire(
  'Berhasil!',
  '{{ $message }}',
  'success'
)
@endif
@if($message = session('error'))
Swal.fire(
  'Gagal!',
  '{{ $message }}',
  'error'
)
@endif
</script>
</body>

</html>
