<!DOCTYPE html>
<html lang="en">
<head>
     <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">    
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
  <link rel="stylesheet" href="{{asset('assets/jobfable/user/style-history.css')}}" />
  <title>History</title>
</head>
<body>
 <div class="container">

    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
 
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
       <script src="https://unpkg.com/feather-icons"></script>

   <!-- NAVBAR -->
   <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)             
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
   <!-- NAVBAR END -->

   <!-- CONTENT START -->
   <section id="history" class="history">
    <h2><span>Riwayat Lamaran</span></h2>

    <div class="container">
       <table id="list_myapplication" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Perusahaan</th>
                <th scope="col">Posisi Pekerjaan</th>
                <th scope="col">Tanggal Lamaran</th>
                <th scope="col">Status</th>
               
                </tr>
                </thead>
                <tbody>
                <?php $no=1; ?>
                    @if($listJobAplication)
                    @foreach($listJobAplication as $list)
                    <tr style="text-align: center">
                        <th scope="row">{{$no++}}</th>
                        <td >{{$list->c_name}}</td>
                        <td>{{$list->name}}</td>
                        <td>{{ date('Y-m-d', strtotime($list->created_at)) }}</td>


                        <td>{{($list->status)?$list->status:'menunggu'}}</td>
                       
                    </tr>                    
                    @endforeach
                    @endif               
                </tbody>
            </table>
    </div> 
  </section>
  
   <!-- CONTENT END -->

   <!-- PAGINATION -->
   <!-- <div class="pagination">
  <a class="desc" href="#">&laquo; Sebelumnya</a>
  <a class="active" href="#">1</a>
  <a href="#">2</a>
  <a href="#">3</a>
  <a href="#">4</a>
  <a href="#">5</a>
  <a href="#">6</a>
  <a class="desc" href="#">Selanjutnya &raquo;</a>
  </div> -->
    
<!-- FOOTER START-->
<footer>
    <div class="social">
      <a href="#"><i data-feather="mail"></i> </a>
    </div>
    <div class="links">
      <a href="{{ url('/') }}#home">Home</a>
      <a href="{{ url('/') }}#about">Tentang Kami</a>
    </div>
    <div class="credit">
      <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
    </div>
  </footer>
</div>
  
    <!-- my javascript -->
    <script src="script.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {        
        $('#list_myapplication').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': false,
            'ordering': true,
            'info': false,
            'autoWidth': false
        });
    });
</script>

 <!-- Feather Icons-->
 <script>
    feather.replace();
  </script>
 </body>
 </html>