<!DOCTYPE html>
<html lang="en">
    <head>
          <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/jobfable/company/edit_lowongan_kerja.css')}}" />
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <title>Edit Lowongan Pekerjaan</title>
    </head>
<body>
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
    </header>
    <!-- navbar end -->

    <!-- Edit Lowongan Kerja start -->
    <main>
        <h1>Edit Lowongan Kerja</h1>
        <section class="form-edit ps-5">
            <form method="post" action="{{route('job.update')}}">
       @csrf
                 <input type="hidden" name="job_id" value="{{$listJob->id}}" >  
                <div class="row mb-3 mt-5">
                  <label for="inputPosisiPekerjaan3" class="col-sm-2 col-form-label">Posisi Pekerjaan</label>
                  <div class="col-sm-5">
                    <input type="text" class="form-control" name="job_name" value="{{$listJob->name}}" id="inputPosisiPekerjaan3">
                  </div>
                </div>
               <div class="row mb-3">
                    <label for="inputGajiPekerjaan3"  class="col-sm-2 col-form-label">Gaji Pekerja</label>
                    <div class="col-sm-5">
                       <select class="form-select" name="job_salary" selected="low"  id="autoSizingSelect">
                            <option value="4.500.000" {{ $listJob->salary == '4.500.000' ? 'selected' : '' }}>&le;4.500.000</option>
                            <option value="4.500.001-7.000.000" {{ $listJob->salary == '4.500.001-7.000.000' ? 'selected' : '' }}>4.500.001 - 7.000.000</option>
                            <option value="7.000.001-10.000.000" {{ $listJob->salary == '7.000.001-10.000.000' ? 'selected' : '' }}>7.000.001 - 10.000.000</option>
                            <option value="10.000.001-15.000.000" {{ $listJob->salary == '10.000.001-15.000.000' ? 'selected' : '' }}>10.000.001-15.000.000</option>
                            <option value="15.000.001-20.000.000" {{ $listJob->salary == '15.000.001-20.000.000' ? 'selected' : '' }}>15.000.001 - 20.000.000</option>
                            <option value="20.000.001" {{ $listJob->salary == '20.000.001' ? 'selected' : '' }}>&ge;20.000.001</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDeskripsiPekerjaan3" class="col-sm-2 col-form-label">Deskripsi Pekerjaan</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_description" value="{{$listJob->description}}" id="inputDeskripsiPekerjaan3" rows="3">{{$listJob->description}}</textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputMinimumKualifikasi3" class="col-sm-2 col-form-label">Minimum Kualifikasi</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_requirement" value="{{$listJob->requirement}}" id="inputMinimumKualifikasi3" rows="3">{{$listJob->requirement}}</textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="autoSizingSelect">Jenis Pekerjaan</label>
                    <div class="col-sm-3">
                        <select class="form-select" name="job_category"  id="autoSizingSelect">
                            <option selected>Pilih</option>                          
                            <option value="it" {{ $listJob->category == 'it' ? 'selected' : '' }}>Teknologi Informasi</option>
                            <option value="design" {{ $listJob->category == 'design' ? 'selected' : '' }}>Desain dan Media</option>
                            <option value="business" {{ $listJob->category == 'business' ? 'selected' : '' }}>Bisnis dan Pemasaran</option>
                            <option value="hrd" {{ $listJob->category == 'hrd' ? 'selected' : '' }}>Personalia dan Legal</option>
                            <option value="prod" {{ $listJob->category == 'prod' ? 'selected' : '' }}>Produksi</option>
                            <option value="finance" {{ $listJob->category == 'finance' ? 'selected' : '' }}>Keuangan</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="autoSizingSelect">Domisili</label>
                    <div class="col-sm-3">
                        <select class="form-select" name="job_city"  id="autoSizingSelect">
                            <option selected>Pilih</option>
                            <option value="jabodetabek" {{ $listJob->address == 'jabodetabek' ? 'selected' : '' }}>JaBoDeTaBek</option>
                            <option value="jawa" {{ $listJob->address == 'jawa' ? 'selected' : '' }}>Pulau Jawa (diluar jabodetabek)</option>
                            <option value="sumatera" {{ $listJob->address == 'sumatera' ? 'selected' : '' }}>Pulau Sumatera</option>
                            <option value="kalimantan" {{ $listJob->address == 'kalimantan' ? 'selected' : '' }}>Pulau Kalimantan</option>
                            <option value="sulawesi" {{ $listJob->address == 'sulawesi' ? 'selected' : '' }}>Pulau Sulawesi</option>
                            <option value="bali" {{ $listJob->address == 'bali' ? 'selected' : '' }}>Pulau Bali</option>
                            <option value="papua" {{ $listJob->address == 'papua' ? 'selected' : '' }}>Pulau Papua</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputJamKerja3" class="col-sm-2 col-form-label">Jam Kerja / Operasional</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control"  name="job_operation"  value="{{$listJob->operation}}" id="inputJamKerja3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="disability">Jenis Disabilitas</label>
                    <div >
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna netra" @if(in_array('Tuna netra', $selectedDisabilities)) checked @endif>
                            Tuna netra
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna rungu" @if(in_array('Tuna rungu', $selectedDisabilities)) checked @endif>
                            Tuna rungu
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna wicara" @if(in_array('Tuna wicara', $selectedDisabilities)) checked @endif>
                            Tuna wicara
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna haptic/Tuna kinestetik" @if(in_array('Tuna haptic/Tuna kinestetik', $selectedDisabilities)) checked @endif>
                            Tuna haptic/Tuna kinestetik
                        </label><br>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputInformasiTambahan3" class="col-sm-2 col-form-label">Informasi Tambahan</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_info" value="{{$listJob->info}}" id="inputInformasiTambahan3" rows="3">{{$listJob->info}}</textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center gap-5 mb-5 mt-5">
                    <a class="btn btn-primary col-3" href="{{route('job.list')}}" >Batal</a>
                    <button class="btn btn-primary col-3" type="submit">Simpan</button>
                </div>
            </form>
        </section>
      </main>
      <!-- Edit Lowongan Pekerjaan End -->

      <!-- Footer Start -->
      <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
      <!-- Footer End -->
    <script>
        feather.replace();
      </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script>
@if($message = session('success'))
Swal.fire(
  'Berhasil!',
  '{{ $message }}',
  'success'
)
@endif
@if($message = session('error'))
Swal.fire(
  'Gagal!',
  '{{ $message }}',
  'error'
)
@endif
</script>
</body>
</html>