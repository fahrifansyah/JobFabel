<!DOCTYPE html>
<html lang="en">
  <head>
      <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">    
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
    <link rel="stylesheet" href="{{asset('assets/jobfable/user/style-jobdetail.css')}}" />
    <title>Job Detail</title>
  </head>
  <body>
        <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
      <script src="https://unpkg.com/feather-icons"></script>

    <div class="container">
      <!-- NAVBAR -->
      <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
      <!-- NAVBAR END -->

      <!-- HEAD START -->
     
        @if($listJob)
        @foreach($listJob as $list => $job)
      <section id="job-detail" class="job-detail"> 
        <h2><span>Detail Pekerjaan</span></h2>

        <div class="row">
          <div class="Profil-img">
            <img src="{{asset('uploads')}}/{{$job->image}}" />
          </div>
          <div class="desc">
            <h3>{{$job->name}}</h3>
            <h4>{{$job->c_name}}</h4>
            <p>{{$job->address}}</p>
            <p>{{$job->salary}}</p>
          </div>
          <div class="apply-button">
           
          </div>
        </div>
      </section>
       @endforeach
        @endif
      <!-- PROFIL END -->
       @if($listJob)
            @foreach($listJob as $list => $job)
      <!-- ABOUT THE JOB START -->
      <section id="description" class="description">
        <h2>Tentang Pekerjaan</h2>

        <div class="desc">
          <br />
          {{-- <p>
            {{$job->description}}
          </p> --}}

          <h4>Deskripsi Pekerjaan</h4>
          <div class="li-desc">
            <p style="white-space: pre-line">{{$job->description}}</p>
          </div>

          <h4>Minimum Kualifikasi</h4>
          <div class="li-desc">
            <p style="white-space: pre-line">{{$job->requirement}}</p>
          </div>

          <h4>Jenis Pekerjaan</h4>
          <p>{{$job->category}}</p>

          <h4>Jam Kerja/Operasional</h4>
          <p>{{$job->operation}}</p>
          {{-- <h4>Jam Kerja/Operasional</h4> --}}
          <section id="experience" class="experience">
            <h4>Jenis Disabilitas</h4>
            <div class="job">
                @if($job->disability)
                <ul>
                  @php
                    $disabilities = explode(',', $job->disability);
                  @endphp
                  @foreach($disabilities as $disability)
                    <li type="none" style="font-weight: 300">{{ trim($disability) }}</li>
                  @endforeach
                </ul>
              @endif
            </div>
        </section>
        <br>
          
          <h4>Informasi Tambahan</h4>
          <p style="white-space: pre-line">{{$job->info}}</p>
        </div>
      </section>
      <!-- ABOUT THE JOB END -->

      <!-- ABOUT THE COMPANY -->
      <section id="description" class="description">
        <h2>Tentang Perusahaan</h2>

        <div class="desc">
          <br />
          <h4>Deskripsi Perusahaan</h4>
          <p>{{$job->c_description}}</p>

          <h4>Jenis Perusahaan</h4>
          <p>{{$job->c_category}}</p>

          
          <h4>Alamat</h4>
          <p>{{$job->address}}</p>

          <h4>Website</h4>
          <p>
            <a href="{{$job->website}}">{{$job->website}}</a>
          </p>

          <h4>Nomor Telepon</h4>
          <p>{{$job->phone}}</p>

          <h4>Bahasa yang Digunakan</h4>
          <p>{{$job->language}}</p>
        </div>
      </section>
      @endforeach
            @endif
      <!-- ABOUT THE COMPANY END -->
      <br />
      <!-- BACK BUTTON -->
      <div class="back-button">
        <a href="{{route('job.list')}}">
          <button class="back" type="submit">Kembali</button>
        </a>
      </div>

      <!-- FOOTER START-->
      <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    </div>
    <!-- FOOTER END -->

    <!-- my javascript -->
    <script src="script.js"></script>

    <!-- Feather Icons-->
    <script>
      feather.replace();
    </script>
  </body>
</html>
