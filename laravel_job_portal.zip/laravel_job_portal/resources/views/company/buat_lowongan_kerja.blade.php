<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <!-- fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
        <!-- My Style -->
       <link rel="stylesheet" href="{{asset('assets/jobfable/company/buat_lowongan_kerja.css')}}" />
        <!-- Bootstrap -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
        <!-- Feather iconsa -->
        <script src="https://unpkg.com/feather-icons"></script>
        <title>Add Job</title>
    </head>
<body>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
    </header>
    <!-- navbar end -->

    <!-- Buat Lowongan Kerja start -->
    <main>
        <h1>Buat Lowongan Kerja</h1>
        <section class="form-edit ps-5">
            <form method="post" action="{{route('job.add')}}">
       @csrf
                <div class="row mb-3 mt-5">
                  <label for="inputPosisiPekerjaan3"   class="col-sm-2 col-form-label">Posisi Pekerjaan</label>
                  <div class="col-sm-5">
                    <input type="text" class="form-control" name="job_name" id="inputPosisiPekerjaan3">
                  </div>
                </div>
                <div class="row mb-3">
                    <label for="inputGajiPekerjaan3"  class="col-sm-2 col-form-label">Gaji Pekerja</label>
                    <div class="col-sm-5">
                       <select class="form-select" name="job_salary"  id="autoSizingSelect">
                            <option selected>Pilih</option>                          
                            <option value="4.500.000"> &le;4.500.000</option>
                        <option value="4.500.001-7.000.000">4.500.001 - 7.000.000</option>
                        <option value="7.000.001-10.000.000">7.000.001 - 10.000.000</option>
                        <option value="10.000.001-15.000.000">10.000.001 - 15.000.000</option>
                        <option value="15.000.001-20.000.000">15.000.001 - 20.000.000</option>
                        <option value="20.000.001">&ge;20.000.001</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputDeskripsiPekerjaan3" class="col-sm-2 col-form-label">Deskripsi Pekerjaan</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_description"  id="inputDeskripsiPekerjaan3" rows="3"></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputMinimumKualifikasi3"  class="col-sm-2 col-form-label">Minimum Kualifikasi</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_requirement" id="inputMinimumKualifikasi3" rows="3"></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="autoSizingSelect">Jenis Pekerjaan</label>
                    <div class="col-sm-3">
                        <select class="form-select" name="job_category"  id="autoSizingSelect">
                            <option selected>Pilih</option>                          
                            <option value="it">Teknologi Informasi</option>
                            <option value="design">Desain dan Media</option>
                            <option value="business">Bisnis dan Pemasaran</option>
                            <option value="hrd">Personalia dan Legal</option>
                            <option value="prod">Produksi</option>
                            <option value="finance">Keuangan</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="autoSizingSelect">Domisili</label>
                    <div class="col-sm-3">
                        <select class="form-select" name="job_city"  id="autoSizingSelect">
                            <option selected>Pilih</option>
                            <option value="jaodetabek">JaBoDeTaBek</option>
                            <option value="jawa">Pulau Jawa (diluar jabodetabek)</option>
                            <option value="sumatera">Pulau Sumatera</option>
                            <option value="kalimantan">Pulau Kalimantan</option>
                            <option value="sulawesi">Pulau Sulawesi</option>
                            <option value="bali">Pulau Bali</option>
                            <option value="papua">Pulau Papua</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputJamKerja3" class="col-sm-2 col-form-label">Jam Kerja / Operasional</label>
                    <div class="col-sm-5">
                        <input type="text" class="form-control" name="job_operation" id="inputJamKerja3">
                    </div>
                </div>
                <div  class="row mb-3">
                    <label for="disability">Jenis Disabilitas</label>
                    <div >
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna netra">
                            Tuna netra
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna rungu">
                            Tuna rungu
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna wicara" >
                            Tuna wicara
                        </label><br>
                        <label>
                            <input type="checkbox" name="disability[]" value="Tuna haptic/Tuna kinestetik" >
                            Tuna haptic/Tuna kinestetik
                        </label><br>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputInformasiTambahan3"  class="col-sm-2 col-form-label">Informasi Tambahan</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="job_info"  id="inputInformasiTambahan3" rows="3"></textarea>
                    </div>
                </div>
                <div class="d-flex justify-content-center gap-5 mb-5 mt-5">
                    <a class="btn btn-primary col-3" href="{{route('job.list')}}" role="button">Batal</a>
                    <button class="btn btn-primary col-3" type="submit">Buat Lowongan</button>
                </div>
            </form>
        </section>
      </main>
      <!-- Buat Lowongan Kerja End -->

      <!-- Footer Start -->
      <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
      <!-- Footer End -->
    <script>
        feather.replace();
      </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script>
@if($message = session('success'))
Swal.fire(
  'Berhasil!',
  '{{ $message }}',
  'success'
)
@endif
@if($message = session('error'))
Swal.fire(
  'Gagal!',
  '{{ $message }}',
  'error'
)
@endif
</script>
</body>
</html>