// toggle class active
const navbarNav = document.querySelector('.navbar-nav');
// ketika menu di click
document.querySelector('#list').onclick = () => {
  navbarNav.classList.toggle('active');
};
//klik di luar sidebar untuk menghilangkan nav
const list = document.querySelector('#list');
document.addEventListener('click', function (e) {
  if (!list.contains(e.target) && !navbarNav.contains(e.target)) {
    navbarNav.classList.remove('active');
  }
});
