<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link rel="stylesheet" href="{{asset('assets/jobfable/company/daftar_pelamar.css')}}" />
    <title>User Apply Job List</title>
</head>

<body>
    <!-- navbar start -->
    <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script> 
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
       <script src="https://unpkg.com/feather-icons"></script>

    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)              
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
    </header>
    <!-- navbar end -->
    <!-- Daftar Pelamar start -->
    <main>
        <h1>Daftar Pelamar</h1>
        <section class="buka-lowongan-kerja">
            <table id="list_company_application"  class="table table-bordered table-striped">
                <thead >
                    <tr>
                        <th scope="col">Nomor</th>
                        <th scope="col">Nama Pencari Kerja</th>
                        <th scope="col">Profil Pencari Kerja</th>
                        <th scope="col" >CV</th>
                        <th scope="col" >Konfirmasi</th>
                    </tr>
                </thead>
                <tbody >
                <?php $no=1; ?>
                    @if($listJobAplication)
                    @foreach($listJobAplication as $jobApp => $list)
                    <tr>
                        <th scope="row">{{$no++}}</th>
                        <td>{{$list->js_name}}</td>
                        <td><a class="tombol" href="{{ route('jobapplication.viewProfile',$list->js_user_id) }}
                            ">Profil</a></td>
                        <td><a class="tombol" href="{{asset('uploads')}}/{{$list->file}}">Download</a></td>
                        <td>
                             @if($list->status =='menunggu')
                            <a class="btn btn-danger" href="{{route('jobapplication.confirm',['id'=>$list->job_id,'status'=>'ditolak','jobseeker_id'=>$list->jobseeker_id])}}">X</a>
                            <a class="btn btn-success" href="{{route('jobapplication.confirm',['id'=>$list->job_id,'status'=>'diterima','jobseeker_id'=>$list->jobseeker_id])}}">✓</a>
                             @else
                            {{$list->status}}
                            @endif
                        </td>
                    </tr>
                    @endforeach
                    @endif
                </tbody>
            </table>
        </section>
       <!--  <section class="tombol-page-lain d-flex justify-content-between">
            <a class="btn btn-primary" href="editprofilecompany.html">Sebelumnya</a>
            <div class="btn-group">
                <a href="#" class="btn btn-outline-primary active" aria-current="page">1</a>
                <a href="#" class="btn btn-outline-primary">2</a>
                <a href="#" class="btn btn-outline-primary">3</a>
            </div>
            <a class="btn btn-primary" href="editprofilecompany.html">Selanjutnya</a>
        </section> -->
    </main>
    <!-- Daftar Pelamar End -->
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
    <!-- Footer End -->
    <script type="text/javascript">
    $(document).ready(function() {        
        $('#list_company_application').DataTable({
            'paging': true,
            'lengthChange': false,
            'searching': false,
            'ordering': true,
            'info': false,
            'autoWidth': false
        });
    });
</script>
    <script>
    feather.replace();

    </script>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>

</html>
