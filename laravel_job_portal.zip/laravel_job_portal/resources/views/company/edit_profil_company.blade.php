<!doctype html>
<html lang="en">
    <head> 
        <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" /> 
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" /> 
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <!-- My Style -->
   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.css')}}" rel="stylesheet">
    <link href="{{asset('assets/plugin/sweetalert2/sweetalert2.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/jobfable/company/edit_profil_company.css')}}" />
    <link href="{{asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css')}}">
    <link rel="stylesheet" href="{{asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css')}}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <!-- Feather iconsa -->
        <script src="https://unpkg.com/feather-icons"></script>
        <title>Edit Profil Company</title>
    </head>
  <body>
    <!-- navbar start -->
        <script src="{{asset('assets/plugin/jquery/jquery.min.js')}}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script src="{{asset('assets/plugin/jquery-modal-master/jquery.modal.min.js')}}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.all.min.js')}}"></script>
    <script src="{{asset('assets/plugin/sweetalert2/sweetalert2.min.js')}}"></script>
    <script src="{{asset('assets/plugin/feather-icons/feather.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js')}}"></script>
    <script src="{{asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js')}}"></script>
      <script src="https://unpkg.com/feather-icons"></script>
    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
        <div class="navbar-nav">
        @if($is_user==1)
            <a id="ja_list" href="{{route('jobapplication.list')}}">Riwayat Lamaran</a>
            <a id="j_detail" href="{{route('jobapplication.detail')}}">Daftar Pekerjaan</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            <a id="js_bookmark" href="{{route('jobapplication.bookmarklist')}}">Tinjau Ulang</a>
        @elseif($is_user==2)
            <a id="j_list" href="{{route('job.list')}}">Buka Lowongan Kerja</a>
            <a href="{{route('company.about')}}">Seputar Kerja</a>  
            @endif
            @if(! $is_user)             
            <button class="btnLogin-popup"><a href="#masuk" rel="modal:open">Login</a></button>
            @endif
        </div>
        <div class="navbar-extra">
             @if($is_user==1)
             <a href="{{ route('jobapplication.detail') }}" id="search"><i data-feather="search"></i></a>
            <a href="{{route('jobseeker.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>
            @elseif($is_user==2)
            <a href="{{ route('search.index') }}" id="search"><i data-feather="search"></i></a>  
            <a href="{{route('company.index')}}" id="profil"><i data-feather="user"></i></a>
            <a href="{{route('logout')}}" id="logout"><i data-feather="log-out"></i></a>            
            @endif
        </div>
    </nav>
    </header>
    <div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="searchModalLabel">Pencarian</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <!-- Isi dengan elemen/form pencarian yang Anda inginkan -->
              <form>
                <!-- Contoh: input pencarian -->
                <div class="mb-3">
                  <label for="searchInput" class="form-label">Kata Kunci</label>
                  <input type="text" class="form-control" id="searchInput" placeholder="Masukkan kata kunci">
                </div>
                <!-- Contoh: tombol submit -->
                <button type="submit" class="btn btn-primary">Cari</button>
              </form>
            </div>
          </div>
        </div>
      </div>
      
      <!-- navbar end -->

      <!-- Edit Profil Start -->
      <main>
        <h1>Edit Profil</h1>
        <section class="form-edit ps-5">
             <form method="post" action="{{route('company.update')}}" enctype="multipart/form-data">
       @csrf
                  <input type="hidden" name="company_id" value="{{$company->id}}">   
                <div class="row mb-3 mt-5">
                  <label for="inputText3" class="col-sm-2 col-form-label">Nama Company</label>
                  <div class="col-sm-5">
                    <input type="text"  required class="form-control" name="company_name" value="{{$company->name}}" id="inputText3">
                  </div>
                </div>
                <div class="row mb-3">
                    <label for="inputUsername3" class="col-sm-2 col-form-label">Username</label>
                    <div class="col-sm-5">
                      <input type="text"  required class="form-control" name="company_username" value="{{$user->username}}" id="inputUsername3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputEmail3" class="col-sm-2 col-form-label">Email</label>
                    <div class="col-sm-5">
                        <input type="text"  required class="form-control" name="company_email" value="{{$user->email}}" id="inputEmail3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputNomortelepon3" class="col-sm-2 col-form-label">Nomor telepon</label>
                    <div class="col-sm-5">
                        <input type="number" class="form-control" name="company_phone" value="{{$company->phone}}" id="inputNomortelepon3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputAlamat3" class="col-sm-2 col-form-label">Alamat</label>
                    <div class="col-sm-5">
                        <input type="text"  required class="form-control" name="company_address" value="{{$company->address}}" id="inputAlamat3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputWebsite3" class="col-sm-2 col-form-label">Website</label>
                    <div class="col-sm-5">
                        <input type="text"  required class="form-control" name="company_website" value="{{$company->website}}" id="inputWebsite3">
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-sm-2 col-form-label">
                        <label for="inputPassword6" class="col-form-label">Password</label>
                    </div>
                    <div class="col-sm-3">
                        <input type="password" id="inputPassword6" name="company_password" placeholder="Password" class="form-control" aria-labelledby="passwordHelpInline">
                        Must be 6 or more character.
                        </span>
                    </div>
                </div>
                <div class="row mb-3">
                    <label class="col-sm-2 col-form-label" for="autoSizingSelect">Jenis Perusahaan</label>
                    <div class="col-sm-5">
                        <input type="tel" class="form-control" name="company_category" value="{{$company->category}}" id="inputKategori3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="exampleFormControlTextarea1" class="col-sm-2 col-form-label">Deskripsi</label>
                    <div class="col-sm-5">
                        <textarea class="form-control" name="company_description" value="{{$company->description}}" id="exampleFormControlTextarea1" rows="3">{{$company->description}}</textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputBahasayangdigunakan3" class="col-sm-2 col-form-label">Bahasa yang digunakan</label>
                    <div class="col-sm-5">
                        <input type="text"  required class="form-control" name="company_language" value="{{$company->language}}" id="inputBahasayangdigunakan3">
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="inputTambahkanfoto3" class="col-sm-2 col-form-label">Tambahkan foto</label>
                    <div class="col-sm-5">
                        <input type="file" class="form-control" name="company_image"  id="inputTambahkanfoto3" accept="image/*">
                    </div>
                </div>
                <div class="d-flex justify-content-center gap-5 mb-5 mt-5">
                    <a class="btn btn-primary col-3" href="{{route('company.index')}}" role="button">Batal</a>
                    <button class="btn btn-primary col-3" type="submit">Simpan</button>
                </div>
            </form>
        </section>
      </main>
      <!-- Edit Profil End -->

      <!-- Footer Start -->
      <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
      <!-- Footer End -->
      
    <script>
        feather.replace();
      </script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
    <script>
@if($message = session('success'))
Swal.fire(
  'Berhasil!',
  '{{ $message }}',
  'success'
)
@endif
@if($message = session('error'))
Swal.fire(
  'Gagal!',
  '{{ $message }}',
  'error'
)
@endif
</script>
  </body>
</html>