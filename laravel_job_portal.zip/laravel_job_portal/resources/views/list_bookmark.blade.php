<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <h2>Bookmark</h2>
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <div class="row mb-2">
        <table id="list_bookmark" class="table ">
            <thead>
                <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th>
                   
                </tr>
            </thead>
            <tbody>
                @if($listJobAplication)
                @foreach($listJobAplication as $list => $job)
                <tr>
                    <td>
                          <img src="{{asset('uploads')}}/{{$job->image}}" alt="" style="width: 50%;">
                    </td>
                    <td>
                          <h3 class="mb-0">{{$job->name}}</h3>
                    <div class="mb-1 text-body-secondary">{{$job->c_name}}</div>
                    <p class="card-text mb-auto">{{$job->address}}</p>   
                    </td>
                    <td>
                           <a href="{{route('jobapplication.apply',['id'=>$job->job_id])}}" class="btn btn-secondary btn-block">
                       Selengkapnya                        
                    </a>              
                    </td>
                    <td>
                          <a href="{{route('jobapplication.deletebookmark',['id'=>$job->job_id])}}" id="bookmark" class="btn-close btn-block">
                    </td>
                 
                </tr>
                 @endforeach 
                @endif
            </tbody>
        </table>
        @if($listJobAplication)
        @foreach($listJobAplication as $list => $job)
        <!-- <div class="col-md-12 ">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative bg-body-tertiary">               
                <div class="col-3 d-none d-lg-block">
                    <img src="{{asset('uploads')}}/{{$job->image}}" alt="" style="width: 50%;">
                </div> 
                <div class="col-6 p-4 d-flex flex-column position-static">
                    <h3 class="mb-0">{{$job->name}}</h3>
                    <div class="mb-1 text-body-secondary">{{$job->c_name}}</div>
                    <p class="card-text mb-auto">{{$job->address}}</p>                    
                </div>  
                <div class="col-2 p-4 d-flex flex-column position-static">
                    <a href="{{route('jobapplication.apply',['id'=>$job->job_id])}}" class="btn btn-secondary btn-block">
                       Selengkapnya                        
                    </a>                     
                </div>  
                 <div class="col-1 p-4 d-flex flex-column position-static">                    
                    <a href="{{route('jobapplication.deletebookmark',['id'=>$job->job_id])}}" id="bookmark" class="btn-close btn-block">
                   </a>
                </div>  
            </div>
        </div> -->
        @endforeach 
        @endif
    </div>
    
</main>
<script>
$(function() {
    $('#list_bookmark').DataTable({
        'paging': true,
        'lengthChange': true,
        'searching': true,
        'ordering': true,
        'info': true,
        'autoWidth': false
    });

});

</script>
