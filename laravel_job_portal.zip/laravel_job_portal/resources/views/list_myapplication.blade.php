<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-8 pt-1">
                  <h2 class="text-start">Riwayat Lamaran</h2>
            </div>
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <article class="blog-post ">           
            <table id="list_myapplication" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Company</th>
                <th scope="col">Posisi Pekerjaan</th>
                <th scope="col">Tanggal Lamaran</th>
                <th scope="col">Status</th>
               
                </tr>
                </thead>
                <tbody>
                    @if($listJobAplication)
                    @foreach($listJobAplication as $list)
                    <tr>
                        <th scope="row">1</th>
                        <td>{{$list->c_name}}</td>
                        <td>{{$list->name}}</td>
                        <td>{{$list->created_at}}</td>

                        <td>{{($list->status)?$list->status:'menunggu'}}</td>
                       
                    </tr>                    
                    @endforeach
                    @endif               
                </tbody>
            </table>
        
    </article>
</main>

<script type="text/javascript">
    $(document).ready(function() {
        $("#delete-link").on("click", function(e) {
            e.preventDefault(); // Prevent the default click behavior of the link
            
            Swal.fire({
                title: 'Are you sure?',
                text: 'This action cannot be undone.',
                showConfirmButton: true,
                showCancelButton: true,
                allowOutsideClick: false,
            }).then((result) => {
                if (result.isConfirmed) {
                    // User clicked "Confirm", proceed with the delete action
                    window.location.href = $(this).attr('href');
                } else {
                    // User clicked "Cancel", do nothing
                }
            });
        });
        $('#list_myapplication').DataTable({
            'paging': true,
            'lengthChange': true,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false
        });
    });
</script>