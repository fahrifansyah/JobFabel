<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <div class="row mb-2">
        <?php $status = (isset($listJobAplication->status))?($listJobAplication->status):''; ?>
        @if($listJob)
        @foreach($listJob as $list => $job)
        <div class="col-md-12 ">
            <div class="row g-0 border rounded overflow-hidden flex-md-row mb-4 shadow-sm h-md-250 position-relative bg-body-tertiary">               
                <div class="col-3 d-none d-lg-block">
                    <img src="{{asset('uploads')}}/{{$job->image}}" alt="" style="width: 50%;">
                </div> 
                <div class="col-6 p-4 d-flex flex-column position-static">
                    <h3 class="mb-0">{{$job->name}}</h3>
                    <div class="mb-1 text-body-secondary">{{$job->c_name}}</div>
                    <div class="mb-1 text-body-secondary">{{$job->address}}</div>
                    <div class="mb-1 text-body-secondary">{{$job->salary}}</div>
                    
                           
                </div>  
                <div class="col-3 p-4 d-flex flex-column position-static">
                    @if($status)
                    <a href="#" class="btn btn-secondary btn-block">
                       Lamaran Sudah Dikirim                        
                    </a>  
                    @else
                    <a href="{{route('jobapplication.send',['id'=>$job->id])}}" class="btn btn-secondary btn-block">
                       Apply Pekerjaan                        
                    </a>  
                    @endif
                </div>  
            </div>
        </div>
        @endforeach
        @endif
    </div>
     <div class="p-4 p-md-5 mb-4 rounded text-body-emphasis bg-body-secondary">
        <div class="col-lg-6 px-0">           
            @if($listJob)
            @foreach($listJob as $list => $job)
             <p class="lead my-3">{{$job->category}}</p>
             <p class="lead my-3">{{$job->description}}</p>
              <p class="lead my-3">{{$job->requirement}}</p>
               <p class="lead my-3">{{$job->requirement}}</p>
            @endforeach
            @endif
            
        </div>
    </div>
    
</main>
