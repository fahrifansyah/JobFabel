<div class="container">
    <header class="lh-1 py-3">
        <div class="row flex-nowrap justify-content-between align-items-center">
            <div class="col-8 pt-1">
                  <h2 class="text-start">Buka Lowongan Pekerjaan</h2>
            </div>
            
            <div class="col-4 d-flex justify-content-end align-items-center">
                <div class="input-group">
                <a class="form-control text-center" href="{{route('job.view')}}">Buat Lowongan Pekerjaan</a>
                </div>
            </div>
        </div>
    </header>
</div>
<main class="container flex-grow-1">
    <article class="blog-post ">           
            <table id="open_job_vacancy" class="table table-bordered table-striped">
                <thead>
                <tr>
                <th scope="col">No</th>
                <th scope="col">Posisi Pekerjaan</th>
                <th scope="col">Daftar Pelamar</th>
                <th scope="col">Tanggal Dibuat</th>
                <th scope="col"></th>
                <th scope="col"></th>
                </tr>
                </thead>
                <tbody>
                    @if($listJob)
                    @foreach($listJob as $list)
                    <tr>
                        <th scope="row">1</th>
                        <td>{{$list->name}}</td>
                        <td><a class="form-control" href="{{route('jobapplication.companylist',['id'=>$list->id])}}">Pelamar</a></td>
                        <td>{{$list->created_at}}</td>
                        <td><a class="form-control" href="{{route('job.edit',['id'=>$list->id])}}">Edit</a></td>
                        <td><a class="form-control" id="delete-link" href="{{route('job.delete',['id'=>$list->id])}}">Hapus</a></td>
                    </tr>                    
                    @endforeach
                    @endif               
                </tbody>
            </table>
        
    </article>
</main>

<script type="text/javascript">
    $(document).ready(function() {
        $("#delete-link").on("click", function(e) {
            e.preventDefault(); // Prevent the default click behavior of the link
            
            Swal.fire({
                title: 'Are you sure?',
                text: 'This action cannot be undone.',
                showConfirmButton: true,
                showCancelButton: true,
                allowOutsideClick: false,
            }).then((result) => {
                if (result.isConfirmed) {
                    // User clicked "Confirm", proceed with the delete action
                    window.location.href = $(this).attr('href');
                } else {
                    // User clicked "Cancel", do nothing
                }
            });
        });
        $('#open_job_vacancy').DataTable({
            'paging': true,
            'lengthChange': true,
            'searching': true,
            'ordering': true,
            'info': true,
            'autoWidth': false
        });
    });
</script>
