<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('konten-jobseeker-1.css') }}" />
    <link href="{{ asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>About Job</title>
</head>

<body>
    <script src="{{ asset('assets/plugin/jquery/jquery.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
    <script src="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js') }}"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
    </nav>
    </header>
    <!-- navbar end -->
    <main>
        <h1>Mengatasi Tantangan dalam Karir bagi Disabilitas</h1>
        <img src="{{ asset('assets/jobfable/img') }}/Disabilitas1.jpg" alt="jobseeker-1">
        <p>Pada era yang semakin inklusif, banyak perusahaan dan organisasi yang berkomitmen untuk memberikan peluang
            kerja yang adil dan setara bagi individu dengan disabilitas. Namun, masih ada beberapa tantangan yang
            mungkin dihadapi oleh para penyandang disabilitas dalam menjalani karir profesional. Berikut ini adalah
            beberapa tips dan saran untuk mengatasi tantangan tersebut: <br><br>
            1. Pendidikan dan Keterampilan: Memiliki pendidikan dan keterampilan yang relevan adalah faktor penting
            dalam membangun karir yang sukses. Dapatkan pendidikan yang sesuai dengan minat dan bakat Anda, dan cari
            pelatihan atau sertifikasi tambahan yang dapat meningkatkan kualifikasi Anda di bidang yang diminati.
            <br><br>
            2. Penemuan dan Pemanfaatan Sumber Daya: Cari tahu tentang program dan sumber daya yang tersedia untuk
            membantu penyandang disabilitas dalam mencari pekerjaan dan mengembangkan karir. Misalnya, ada lembaga atau
            organisasi yang menyediakan pelatihan, mentorship, atau bantuan dalam mencari pekerjaan yang sesuai dengan
            kebutuhan dan kemampuan Anda. <br><br>
            3. Komunikasi yang Efektif: Pelajari cara berkomunikasi dengan jelas dan efektif dengan rekan kerja, atasan,
            dan tim. Jika diperlukan, jelaskan dengan tegas kebutuhan atau perubahan yang mungkin diperlukan untuk
            mendukung produktivitas Anda di tempat kerja. <br><br>
            4. Pemahaman dan Kesadaran: Berkomunikasilah dengan tim atau rekan kerja Anda tentang kebutuhan atau
            keterbatasan yang mungkin Anda hadapi. Meningkatkan pemahaman dan kesadaran tentang disabilitas dapat
            membantu menciptakan lingkungan kerja yang inklusif dan mendukung. <br><br>
            5. Penyesuaian Lingkungan Kerja: Jika diperlukan, ajukan permintaan penyesuaian atau aksesibilitas yang
            diperlukan untuk memastikan kenyamanan dan kesetaraan dalam menjalankan tugas. Misalnya, permintaan
            peralatan khusus, penyesuaian jadwal kerja, atau modifikasi fisik ruang kerja. <br><br>
            6. Networking dan Mentoring: Jalin hubungan dengan profesional lain di bidang yang sama melalui kegiatan
            jaringan atau mentoring. Mereka dapat memberikan wawasan dan dukungan yang berharga dalam menghadapi
            tantangan karir. <br><br>
            7. Pemahaman Hak dan Perlindungan: Ketahui hak-hak Anda sebagai pekerja dengan disabilitas dan manfaat yang
            tersedia. Pahami juga undang-undang atau kebijakan yang melindungi hak-hak Anda di tempat kerja. <br><br>
            8. Perencanaan Karir: Buatlah rencana karir yang jelas dan tetapkan tujuan yang dapat dicapai. Pemahami
            peluang karir di bidang yang diminati, identifikasi kekuatan Anda, dan cari kesempatan untuk terus
            mengembangkan diri. <br><br>
            Mengatasi tantangan dalam karir bagi penyandang disabilitas tidaklah mudah, tetapi dengan pendekatan yang
            tepat, dedikasi, dan dukungan yang tepat, Anda dapat meraih kesuksesan dan membangun karir yang memuaskan.
            Ingatlah untuk terus memperkuat kepercayaan diri dan mencari peluang yang tepat untuk berkembang.
        </p>
        <!-- BACK BUTTON -->
        <div class="back-button">
            <a href="{{ route('company.about') }}">
                <button class="back" type="submit">Kembali</button>
            </a>
        </div>
    </main>
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
  <!-- Footer End -->
  <script>
      feather.replace();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
  </script>
</body>

</html>


