<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="csrf-token" content="{{ csrf_token() }}" />
    <!-- fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap"
        rel="stylesheet" />
    <!-- My Style -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('konten-company-1.css') }}" />
    <link href="{{ asset('assets/plugin/@fortawesome/fontawesome-free/css/all.min.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/plugin/datatables.net-dt/css/jquery.dataTables.min.css') }}">
    <link rel="stylesheet"
        href="{{ asset('assets/plugin/datatables.net-responsive-dt/css/responsive.dataTables.min.css') }}">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>About Job</title>
</head>

<body>
    <script src="{{ asset('assets/plugin/jquery/jquery.min.js') }}"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
    </script>
    <script src="{{ asset('assets/plugin/jquery-modal-master/jquery.modal.min.js') }}"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.all.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/sweetalert2/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/feather-icons/feather.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net/js/jquery.dataTables.min.js') }}"></script>
    <script src="{{ asset('assets/plugin/datatables.net-dt/js/dataTables.dataTables.min.js') }}"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <!-- navbar start -->
    <header>
    <nav class="navbar">
        <a href="{{route('home.index')}}" class="navbar-logo">JobFabel</a>
    </nav>
    </header>
    <!-- navbar end -->
    <main>
        <h1>Menyesuaikan Proses Rekrutmen untuk Menyambut Pekerja Disabilitas</h1>
        <img src="{{ asset('assets/jobfable/img') }}/Company1.jpg" alt="company-2">
        <p>Menciptakan lingkungan kerja yang inklusif dan menerima semua individu, termasuk pekerja dengan disabilitas,
            adalah langkah penting dalam mencapai keberagaman dan kesetaraan di tempat kerja. Salah satu langkah awal
            yang dapat diambil adalah dengan menyesuaikan proses rekrutmen agar lebih ramah terhadap pekerja
            disabilitas. Berikut ini adalah beberapa tips dan trik penting yang dapat membantu perusahaan menyesuaikan
            proses rekrutmen mereka: <br><br>

            1. Menghapus Hambatan Fisik: Pastikan area rekrutmen dan tempat wawancara dapat diakses dengan mudah oleh
            pekerja dengan disabilitas. Perhatikan kebutuhan aksesibilitas seperti akses kursi roda, ramah tunanetra,
            dan tanda petunjuk yang jelas.<br><br>

            2. Komunikasi yang Inklusif: Sediakan pilihan komunikasi yang inklusif, seperti melalui email, teks, atau
            aplikasi pesan, selain komunikasi lisan. Ini akan membantu pekerja dengan disabilitas pendengaran atau
            berbicara untuk tetap terlibat dalam proses rekrutmen.<br><br>

            3. Penyediaan Informasi yang Jelas: Saat memposting lowongan kerja, berikan informasi yang jelas tentang
            kemampuan atau keahlian yang diperlukan untuk posisi tersebut. Hindari menggunakan jargon yang tidak
            familiar atau ambigu yang dapat membingungkan calon pekerja dengan disabilitas.<br><br>

            4. Fleksibilitas dalam Metode Evaluasi: Pertimbangkan untuk memberikan fleksibilitas dalam metode evaluasi,
            seperti melalui wawancara video atau telepon, jika calon pekerja memiliki keterbatasan mobilitas atau
            kesulitan untuk menghadiri wawancara langsung.<br><br>

            5. Memastikan Kebijakan Non-Diskriminasi: Pastikan kebijakan perusahaan tidak mendiskriminasi pekerja dengan
            disabilitas. Semua calon pekerja harus dievaluasi berdasarkan kualifikasi dan kompetensi yang relevan, bukan
            berdasarkan disabilitas mereka.<br><br>

            6. Kolaborasi dengan Organisasi yang Mendukung Disabilitas: Jalin kerja sama dengan organisasi atau lembaga
            yang mendukung pekerja dengan disabilitas. Mereka dapat memberikan saran dan bimbingan dalam menyesuaikan
            proses rekrutmen dan menemukan calon pekerja potensial.<br><br>

            7. Pelatihan dan Kesadaran: Sediakan pelatihan kepada staf rekrutmen tentang inklusi dan kesadaran terhadap
            keberagaman, termasuk pemahaman tentang kebutuhan dan tantangan yang dihadapi oleh pekerja dengan
            disabilitas. Ini akan membantu mereka dalam melakukan proses rekrutmen yang lebih sensitif dan
            inklusif.<br><br>

            8. Menyediakan Dukungan Setelah Penerimaan: Setelah mempekerjakan pekerja dengan disabilitas, pastikan untuk
            menyediakan dukungan dan akomodasi yang diperlukan agar mereka dapat bekerja dengan optimal. Ini dapat
            mencakup penyesuaian tugas, modifikasi lingkungan kerja, atau bimbingan khusus.<br><br>

            Dengan menerapkan tips dan trik di atas, perusahaan dapat menciptakan proses rekrutmen yang lebih inklusif
            dan menyambut pekerja disabilitas dengan baik. Ini tidak hanya akan memberikan peluang kerja yang lebih luas
            bagi individu dengan disabilitas, tetapi juga akan membawa manfaat bagi perusahaan dengan meningkatkan
            keberagaman, kreativitas, dan produktivitas di tempat kerja.
        </p>
        <!-- BACK BUTTON -->
        <div class="back-button">
            <a href="{{ route('company.about') }}">
                <button class="back" type="submit">Kembali</button>
            </a>
        </div>
    </main>
    <!-- Footer Start -->
    <footer>
        <div class="social">
          <a href="#"><i data-feather="mail"></i> </a>
        </div>
        <div class="links">
          <a href="{{ url('/') }}#home">Home</a>
          <a href="{{ url('/') }}#about">Tentang Kami</a>
        </div>
        <div class="credit">
          <p>Created by <a href="">@Jofe1</a>. | &copy; 2023.</p>
        </div>
      </footer>
  <!-- Footer End -->
  <script>
      feather.replace();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous">
  </script>
</body>

</html>

