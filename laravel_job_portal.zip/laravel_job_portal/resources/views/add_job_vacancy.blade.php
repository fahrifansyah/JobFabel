<main class="container flex-grow-1">
    <form method="post" action="{{route('job.add')}}">
       @csrf
        <div class="position-relative overflow-hidden p-0 text-center ">
            <h2 class="text-start">Buat Lowongan Pekerjaan</h2>
        </div>        

        <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">        
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_name" placeholder="Posisi Pekerjaan">
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_salary" placeholder="Gaji Pekerjaan">
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_description" placeholder="Deskripsi Pekerjaan">
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_requirement" placeholder="Minimum Kualifikasi">
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_category" placeholder="Jenis Pekerjaan">
            </div>
              <div class="mb-3">                   
                <input type="text" class="form-control" name="job_operation" placeholder="Jam Kerja / Operasional">
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_info" placeholder="Informasi Tambahan">
            </div>
            
            
            <div class="row">       
                <div class="col-md-6">
                    <a href="{{route('job.list')}}" class="btn btn-secondary form-control">Batal</a>
                </div>  
                <div class="col-md-6">
                    <button type="submit" class="btn btn-secondary form-control">Simpan</button>
                </div>   
            </div>
        </div>        
    </form>
    
    
   
</main>