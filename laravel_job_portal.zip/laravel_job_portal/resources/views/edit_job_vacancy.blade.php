<main class="container flex-grow-1">
    <form method="post" action="{{route('job.update')}}">
       @csrf
        <div class="position-relative overflow-hidden p-0 text-center ">
            <h2 class="text-start">Edit Lowongan Pekerjaan</h2>
        </div>        

        <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-body-tertiary">      
            <input type="hidden" name="job_id" value="{{$listJob->id}}" >  
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_name" value="{{$listJob->name}}" >
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_salary" value="{{$listJob->salary}}" >
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_description" value="{{$listJob->description}}" >
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_requirement" value="{{$listJob->requirement}}" >
            </div>
            <div class="mb-3">                   
                <input type="text" class="form-control" name="job_category" value="{{$listJob->category}}" >
            </div>
              <div class="mb-3">                   
                <input type="text" class="form-control" name="job_operation"  value="{{$listJob->operation}}">
            </div>
            <div class="mb-3">                    
                <input type="text" class="form-control" name="job_info" value="{{$listJob->info}}">
            </div>
            
            
            <div class="row">       
                <div class="col-md-6">
                    <a href="{{route('job.list')}}" class="btn btn-secondary form-control">Batal</a>
                </div>  
                <div class="col-md-6">
                    <button type="submit" class="btn btn-secondary form-control">Simpan</button>
                </div>   
            </div>
        </div>        
    </form>
    
    
   
</main>