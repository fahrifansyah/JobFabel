document.getElementById('search').addEventListener('click', function() {
    document.getElementById('searchPopup').classList.add('show');
  });
  
  document.getElementById('searchButton').addEventListener('click', function() {
    // Lakukan pencarian
    var searchTerm = document.getElementById('searchInput').value;
    console.log('Pencarian:', searchTerm);
  });
  
  document.addEventListener('click', function(event) {
    var searchPopup = document.getElementById('searchPopup');
    var search = document.getElementById('search');
  
    if (!searchPopup.contains(event.target) && event.target !== search) {
      searchPopup.classList.remove('show');
    }
  });
  